<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFuzziesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fuzzies', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('kecamatan');
            $table->integer('jumlah_donatur');
            $table->integer('jumlah_kurir');
            $table->string('persentase_rekomendasi');
            $table->string('Rekomendasi');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fuzzies');
    }
}
