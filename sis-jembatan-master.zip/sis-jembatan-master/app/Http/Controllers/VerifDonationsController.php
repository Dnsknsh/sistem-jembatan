<?php

namespace App\Http\Controllers;

use App\Donations;
use Illuminate\Http\Request;

class VerifDonationsController extends Controller
{


    public function index()
    {
        $donation = Donations::where('status', 0)->get();
        return view('pages.dashboard.manager.donation.index',compact('donation'));
    }

    public function verification(Request $request,$id)
    {
        $donation = Donations::find($id);
        $donation->status = $request->status;
        $donation->save();
        return redirect()->back()->with('success','Berhasil mengubah status Kampanye Donasi');
    }


    public function create()
    {

    }


    public function store(Request $request)
    {
        //
    }


    public function show($id)
    {
        $donation = Donations::find($id);
        return view('pages.dashboard.manager.donation.show',compact('donation'));
    }

    public function edit($id)
    {

    }


    public function update(Request $request, $id)
    {

    }


    public function destroy($id)
    {

    }
}
