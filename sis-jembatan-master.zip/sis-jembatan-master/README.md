*Catatan

Users Role

[0] = Normal (Donatur)
[1] = Courirer
[2] = Administrator Pusat
[3] = Manager
[4] = Pakar

Status Aktivitas Donasi
// Logistik
[0] = Sedang Mencari Kurir Terdekat
[1] = Kurir Ditemukan (Sudah ada kurir yang bertanggung jawab)
[2] = Sudah Di Jemput
[3] = Sudah Di Gudang Logistik
//Money
[4] = Sudah Di Transfer 

