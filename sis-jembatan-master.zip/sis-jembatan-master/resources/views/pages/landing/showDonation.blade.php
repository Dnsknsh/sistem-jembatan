@extends('layouts.landing.master')
@section('title', 'Yuk Donasi !')
@section('main')
@include('components.landing.header')
<main>
      <!-- Hero for FREE version -->
      <section class="section section-lg section-hero section-shaped" style="min-height:400px">
        <!-- Background circles -->
        <div class="shape shape-style-1 shape-primary">
          <span class="span-150"></span>
          <span class="span-50"></span>
          <span class="span-50"></span>
          <span class="span-75"></span>
          <span class="span-100"></span>
          <span class="span-75"></span>
          <span class="span-50"></span>
          <span class="span-100"></span>
          <span class="span-50"></span>
          <span class="span-100"></span>
        </div>

      </section>



    <section class="section">
            <div class="container">
              <div class="card card-profile shadow mt--300">
                <div class="px-4">
                  <div class="row ">
                      <div class="col-lg-12 mt-2 ml-4 d-block">
                            <h2>{{$donation->title}}</h2>
                                                <span class="badge badge-pill badge-primary">{{$donation->location}}</span>
                                                @if ($donation->acc_logistic == "on")
                                                <span class="badge badge-pill badge-warning"><i class="fa fa-truck"></i></span>
                                                @endif
                                                @if($donation->acc_money == "on")
                                                <span class="badge badge-pill badge-success"><i class="fa fa-money"></i></span>
                                                @endif
                      </div>
                    <div class="col-lg-7">
                        <div class="p-3">
                                <img src="{{asset('/upload/donation/'.$donation->title.'_'.$donation->startDate.'/'.$donation->thumbnail)}}" alt="" class="img-fluid">
                        </div>
                        <p class="lead text-dark mt-4 ml-3">
                            {{$donation->description}}
                        </p>
                    </div>
                    <div class="col-lg-5 ">
                            <div class="headroom make-me-sticky">
                                    <div class="progress-wrapper">
                                            <div class="progress">
                                              <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
                                            </div>
                                          </div>
                                          <div class="row">
                                              <div class="col-6 text-dark">
                                                    <small>
                                                            Mulai<br>{{date('d-m-Y', strtotime($donation->startDate))}}
                                                    </small>
                                              </div>
                                              <div class="col-6 text-dark text-right">
                                                    <small>
                                                            Selesai<br>{{date('d-m-Y', strtotime($donation->endDate))}}
                                                    </small>
                                              </div>
                                          </div>
                                    <button type="button" class="btn btn-primary btn-block mt-4" data-toggle="modal" data-target="#donation">Donasi Sekarang</button>
                            </div>
                            <hr>
<ul class="list-group mb-5">
    @foreach ($activity as $activity)
    <li class="list-group-item">

            @if ($activity->category == "money")
            <strong>{{$activity->User['name']}}</strong> Telah Mendonasikan Uang Sebesar Rp.{{$activity->count_money}}
            @elseif($activity->category == "logistic")
            <strong>{{$activity->User['name']}}</strong> Telah Mendonasikan {{$activity->description_logistic}}
            @endif
        </li>
    @endforeach
</ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>



  </main>
  <!-- Modal -->
<div class="modal fade" id="donation" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Donation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    @auth
    <form action="{{route('give-donation.store')}}" method="POST">
            @csrf
            <div class="modal-body">
              <div class="row">
                <div class="col-12">

                        <div class="form-group">
                            <label for="category">Category</label>
                                <select name="category" id="category" class="form-control" required>

                                    @if($donation->acc_money != NULL && $donation->acc_logistic != NULL)
                                    <option value="" selected disabled>Pilih Category</option>
                                    <option value="logistic">Logistik</option>
                                    <option value="money">Money</option>
                                    @elseif ($donation->acc_money == "on")
                                    <option value="" selected disabled>Pilih Category</option>
                                    <option value="money">Money</option>
                                    @elseif($donation->acc_logistic == "on")
                                    <option value="" selected disabled>Pilih Category</option>
                                    <option value="logistic">Logistic</option>
                                    @endif
                                </select>
                            </div>
                    <div class="form-group" id="nominalMoney" style="display:none">
                                    <label for="name">Nominal</label>
                                      <input class="form-control" name="count_money" placeholder="Nominal Donasi" type="number">
                    </div>
                    <div class="form-group" id="deskripsiLogistik" style="display:none">
                        <label for="name">Deskripsi Logistik(Ex. Pakaian)</label>
                            <input type="text" class="form-control" name="description_logistic" placeholder="Deskripsi Logistik">
                    </div>
                    <div class="form-group" id="nominalLogistic" style="display:none">
                            <label for="name">Nominal Logistik</label>
                              <input class="form-control" name="count_logistic" placeholder="Nominal Donasi" type="number">
            </div>
            <div class="form-group" id="satuanLogistic" style="display:none">
                    <label for="name">Satuan Logistik(Ex.Karung,Buah)</label>
                      <input class="form-control" name="satuan_logistic" placeholder="Satuan Logistic(Ex.Karung, Buah)" type="text">
    </div>
                    <div class="form-group" id="maps" style="display:none">
                        <label for="">Lokasi Anda</label>
                        <div class="form-control" id="googleMap" style="width:100%;height:250px;"></div>
                        <textarea name="address" id="address" class="form-control mt-3" rows="5"></textarea>
                    </div>
                    <div class="form-group" style="display:none">
                            <input id="langtitude" type="hidden" name="langtitude">
                            <input id="longtitude" type="hidden" name="longtitude">
                            <input id="kecamatan" type="hidden" name="kecamatan">
                            <input id="postal_code" type="hidden" name="kode_pos">
                            <input type="hidden" name="don_id" value="{{$donation->id}}">
                    </div>

                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Donasi</button>
            </div>

          </form>
    @endauth
@guest
    <div class="modal-body">
        <strong>Anda Harus Login terlebih Dahulu untuk Berdonasi</strong>
    <a href="{{route('login')}}" class="mt-3 btn btn-primary btn-block">Login</a>
    </div>
@endguest

    </div>
  </div>
</div>
  @include('components.landing.footer')
@endsection
@section('custom-js')
    <script>
    $(document).ready(function(){
        $('#category').change(function(){
            let selectedCategory = $(this).children("option:selected").val();
        if(selectedCategory == 'logistic'){
            $('#nominalMoney').css('display','none');
            $('#nominalLogistic').css('display','block');
            $('#satuanLogistic').css('display','block');
            $('#deskripsiLogistik').css('display','block');
            $('#maps').css('display','block');
        }else if(selectedCategory == 'money'){
            $('#nominalLogistic').css('display','none');
            $('#satuanLogistic').css('display','none');
            $('#nominalMoney').css('display','block');
            $('#deskripsiLogistik').css('display','none');
            $('#maps').css('display','none');
        }
        });
    });

    // variabel global marker
var marker,infoWindow;
      function taruhMarker(peta, posisiTitik){
          if( marker ){
            // pindahkan marker
            marker.setPosition(posisiTitik);
          } else {
            // buat marker baru
            marker = new google.maps.Marker({
              position: posisiTitik,
              map: peta
            });
          }
              convert_latlng(posisiTitik);
           // isi nilai koordinat ke form
          document.getElementById("langtitude").value = posisiTitik.lat();
          document.getElementById("longtitude").value = posisiTitik.lng();
      }
      // merubah geotag menjadi alamat
      function convert_latlng(pos) {
       // membuat geocoder
      var geocoder = new google.maps.Geocoder();
       geocoder.geocode({'latLng': pos}, function(r) {
        if (r && r.length > 0) {
            function placeToAddress(place){
        var address = {};
        place.address_components.forEach(function(c) {
            switch(c.types[0]){
                case 'administrative_area_level_3':     //  Note some countries don't have states
                    address.kec = c;
                    break;
                case 'postal_code':
                    address.Zip = c;
                    break;
            }
        });

        return address;
    }
        var str = placeToAddress(r[0]).kec.short_name;
        var res = str.slice(4, str.length);
        document.getElementById('kecamatan').value = res;
        document.getElementById('postal_code').value = placeToAddress(r[0]).Zip.short_name;
        document.getElementById('address').value = r[0].formatted_address;
        } else {
         document.getElementById('address').value = 'Alamat tidak di temukan di lokasi !!';
        }
       });
      }
      function initialize() {
        var propertiPeta = {
          center:new google.maps.LatLng(-7.687466468355338,110.41204980722989),
          zoom:15,
          mapTypeId:google.maps.MapTypeId.ROADMAP,
          mapTypeControl: true,
          streetViewControl: false,
        };
        var peta = new google.maps.Map(document.getElementById("googleMap"), propertiPeta);
        // even listner ketika peta diklik
        google.maps.event.addListener(peta, 'click', function(event) {
          taruhMarker(this, event.latLng);
        });
      }
      // event jendela di-load
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>
@endsection
