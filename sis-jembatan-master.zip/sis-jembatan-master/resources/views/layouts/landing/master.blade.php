<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Sistem Jemput Bantuan">
  <meta name="author" content="Space-Z">
  <title>@yield('title') - Sistem Jemput Bantuan</title>
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
<link href="{{asset('/landing/vendor/nucleo/css/nucleo.css')}}" rel="stylesheet">
<link href="{{asset('/landing/vendor/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">

<link type="text/css" href="{{asset('/landing/css/main.css')}}" rel="stylesheet">
</head>

<body>


@yield('main')

  <!-- Core -->
<script src="{{asset('/landing/vendor/jquery/jquery.min.js')}}"></script>
<script src="{{asset('/landing/vendor/popper/popper.min.js')}}"></script>
<script src="{{asset('/landing/vendor/bootstrap/bootstrap.min.js')}}"></script>
<script src="{{asset('/landing/vendor/headroom/headroom.min.js')}}"></script>
  <!-- Optional JS -->
<script src="{{asset('/landing/vendor/onscreen/onscreen.min.js')}}"></script>
<script src="{{asset('/landing/vendor/nouislider/js/nouislider.min.js')}}"></script>
<script src="{{asset('/landing/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{asset('/landing/js/main.js')}}"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCNoV504QEhGxE0svdnhqHnYmNrOXakTQo"
    type="text/javascript"></script>
@yield('custom-js')
</body>

</html>
