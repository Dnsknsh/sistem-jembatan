<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDonationsActivitiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('donations_activities', function (Blueprint $table) {
            $table->Increments('id');
            $table->integer('status');
            $table->Integer('kurir_id')->unsigned()->index()->nullable();
            $table->Integer('don_id')->unsigned()->index();
            $table->Integer('donatur_id')->unsigned()->index();
            $table->Integer('drop_id')->unsigned()->index()->nullable();
            $table->string('langtitude')->nullable();
            $table->string('longtitude')->nullable();
            $table->string('kecamatan')->nullable();
            $table->string('kode_pos')->nullable();
            $table->text('address')->nullable();
            $table->integer('count_money')->nullable();
            $table->integer('count_logistic')->nullable();
            $table->string('satuan_logistic')->nullable();
            $table->text('description_logistic')->nullable();
            $table->integer('metode');
            $table->string('category');
            $table->timestamps();
            $table->foreign('don_id')
                    ->references('id')
                    ->on('donations')
                    ->onDelete('CASCADE')
                    ->onUpdate('CASCADE');
            $table->foreign('kurir_id')
                    ->references('id')
                    ->on('couriers')
                    ->onDelete('CASCADE')
                    ->onUpdate('CASCADE');
            $table->foreign('donatur_id')
                    ->references('id')
                    ->on('users')
                    ->onDelete('CASCADE')
                    ->onUpdate('CASCADE');
            $table->foreign('drop_id')
                    ->references('id')
                    ->on('drop_points')
                    ->onDelete('CASCADE')
                    ->onUpdate('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('donations_activities');
    }
}
