<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Couriers;
use App\DropPoints;
use App\Fuzzy;
use App\PakarSettings;

class CourierController extends Controller
{
    public function index()
    {
        $kurir = Couriers::all();
        return view('pages.dashboard.admin.kurir.index', compact('kurir'));
    }


    public function create()
    {
        $dropPoint = DropPoints::all();
        return view('pages.dashboard.admin.kurir.add',compact('dropPoint'));
    }


    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'nik' => 'required',
            'handphone' => 'required',
            'foto' => 'required',
            'foto.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'ktp' => 'required',
            'ktp.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'

        ]);

        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }


        $kurir = new Couriers();
        $kurir->name = $request->name;
        if($request->hasfile('foto')){
            $image_foto=  $request->file('foto');
            $name_foto=generateRandomString().'.'.$image_foto->getClientOriginalExtension();
            $image_foto->move(public_path().'/upload/'.$request->drop_id.'/kurir/'.$request->nik.'/foto/',$name_foto);
            $data_foto = $name_foto;
        }
        if($request->hasfile('ktp')){
            $image_ktp=  $request->file('ktp');
            $name_ktp=generateRandomString().'.'.$image_ktp->getClientOriginalExtension();
            $image_ktp->move(public_path().'/upload/'.$request->drop_id.'/kurir/'.$request->nik.'/ktp/', $name_ktp);
            $data_ktp = $name_ktp;
        }
        if($request->hasfile('ktp'))
        {
            $kurir->ktp=$data_ktp;
        }
        if($request->hasfile('foto'))
        {
            $kurir->foto=$data_foto;
        }
        $kurir->handphone = $request->handphone;
        $kurir->drop_id = $request->drop_id;
        $kurir->address = $request->address;
        $kurir->nik = $request->nik;
        $kurir->save();

        $posko =DropPoints::find($request->drop_id);
        $posko->jumlah_kurir = $posko->jumlah_kurir + 1;
        $posko->save();



        function fuzzyTsukamoto($xDonatur, $xKurir){

            $pakarSettings = PakarSettings::first();

            if($xDonatur <= number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah)){

                $phiDonaturBanyak = 0;
                $phiDonaturSedikit = 0;

            }else if($xDonatur >= number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah) || $xDonatur <= number_format(json_decode($pakarSettings->donaturBanyak)->batasAtas)){

            //Keanggotaan Donatur Banyak
            $phiDonaturBanyak = ($xDonatur - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah)) / (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah));

            //Keanggotaan Donatur Sedikit
            $phiDonaturSedikit = (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - $xDonatur) / (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah));

            }else if($xDonatur >= number_format(json_decode($pakarSettings->donaturBanyak)->batasAtas)){
                $phiDonaturBanyak = 1;
                $phiDonaturSedikit = 1;
            }

            if($xKurir <= number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah)){

                $phiKurirBanyak = 0;
                $phiKurirSedikit = 0;

            }else if($xKurir >= number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah) || $xKurir <= number_format(json_decode($pakarSettings->kurirBanyak)->batasAtas)){


            //Keanggotaan Kurir Sedikit
            $phiKurirSedikit = (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - $xKurir) / (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah));
            //Keanggotaan Kurir Banyak
            $phiKurirBanyak = ($xKurir - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah)) / (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah));

            }else if($xKurir >= number_format(json_decode($pakarSettings->kurirBanyak)->batasAtas)){
                $phiKurirBanyak = 1;
                $phiKurirSedikit = 1;
            }

    //IF DONATUR BANYAK DAN KURIR BANYAK MAKA REKOMENDASI TINGGI
    $r1 = min($phiDonaturBanyak , $phiKurirBanyak);
    //IF DONATUR BANYAK DAN KURIR SEDIKIT MAKA REKOMENDASI TINGGI
    $r2 =min($phiDonaturBanyak , $phiKurirSedikit);
    //IF DONATUR SEDIKIT DAN KURIR BANYAK MAKA REKOMENDASI RENDAH
    $r3 =min($phiDonaturSedikit , $phiKurirBanyak);
    //IF DONATUR SEDIKIT DAN KURIR SEDIKIT MAKA REKOMENDASI RENDAH
    $r4 =min($phiDonaturSedikit , $phiKurirSedikit);


    //Cari nilai z1 lihat himpunan TINGGI:
    $z1 = ($r1*100) + 0;
    //Cari nilai z2  lihat himpunan TINGGI:
    $z2 = ($r2*100) + 0;
    //Cari nilai z3 lihat himpunan RENDAH
    $z3= 100 - ($r3*100);
    //Cari nilai z4 lihat himpunan RENDAH:
    $z4 = 100 - ($r4*100);

    if($r1 + $r2 + $r3 + $r4 == 0){
        return 0;
    }else {
        $defuzzifikasi = ( ($r1*$z1) +  ($r2*$z2) +  ($r3*$z3) +  ($r4*$z4)) / ( $r1 + $r2 + $r3 + $r4);
        return $defuzzifikasi;
    }


        }

        $cekKecamatan = Fuzzy::where('kecamatan',$posko->kecamatan)->first();
        if($cekKecamatan){
            $fuzzy = $cekKecamatan;
            $fuzzy->jumlah_kurir +=1;
            $fuzzy->persentase_rekomendasi = fuzzyTsukamoto($fuzzy->jumlah_donatur,$fuzzy->jumlah_kurir);
            if($fuzzy->persentase_rekomendasi > 50){
                $fuzzy->rekomendasi = "REKOMENDASI TINGGI";
            }else {
                $fuzzy->rekomendasi = "REKOMENDASI RENDAH";
            }
            $fuzzy->save();
        }else{
            $fuzzy = new Fuzzy;
            $fuzzy->kecamatan = $posko->kecamatan;
            $fuzzy->jumlah_kurir = 1;
            $fuzzy->jumlah_donatur=0;
            $fuzzy->persentase_rekomendasi = fuzzyTsukamoto($fuzzy->jumlah_donatur,$fuzzy->jumlah_kurir);
            if($fuzzy->persentase_rekomendasi > 50){
                $fuzzy->rekomendasi = "REKOMENDASI TINGGI";
            }else {
                $fuzzy->rekomendasi = "REKOMENDASI RENDAH";
            }
            $fuzzy->save();
        }


        return redirect()->route('kurir.index')->with('success', 'Berhasil Menambah Kurir');
    }


    public function show($id)
    {
        $kurir = Couriers::find($id);
        return view('pages.dashboard.admin.kurir.show',compact('kurir'));
    }


    public function edit($id)
    {
        $kurir = Couriers::find($id);
        $dropPoint = DropPoints::all();
        return view('pages.dashboard.admin.kurir.edit',compact('kurir','dropPoint'));
    }


    public function update(Request $request, $id)
    {
        $kurir = Couriers::find($id);
        $kurir->name = $request->name;
        $kurir->handphone = $request->handphone;
        $kurir->drop_id = $request->drop_id;
        $kurir->address = $request->address;
        $kurir->nik = $request->nik;
        $kurir->ktp = 1;
        $kurir->foto = 1;
        $kurir->save();

        return redirect()->back()->with('success', 'Berhasil Mengubah Kurir');
    }


    public function destroy(Request $request,$id)
    {
        $kurir = Couriers::find($id);
        $kurir->delete();

        $posko =DropPoints::find($request->drop_id);
        $posko->jumlah_kurir = $posko->jumlah_kurir - 1;
        $posko->save();

        return redirect()->back()->with('success', 'Berhasil Menghapus Kurir');
    }
}
