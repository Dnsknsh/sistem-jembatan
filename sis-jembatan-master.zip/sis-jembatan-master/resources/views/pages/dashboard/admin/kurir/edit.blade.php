@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Tambah Kurir</h1>
            </div>

            <div class="row">
              <div class="col-md-12">


                <!-- Bagian Kartu Ketika Di perbarui -->

                <div class="card shadow mb-4">
                  <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold">Biodata Kurir</h6>
                  </div>
                  <div class="card-body">
                  <form action="{{route('kurir.update',$kurir->id)}}" method="POST">
                    @csrf
                {{method_field('PUT')}}
                      <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="role" class="small font-weight-bold">NIK / No. KTP</label>
                            <input name="nik" type="text" placeholder="NIK/No. KTP" class="form-control small" value="{{$kurir->nik}}">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="role" class="small font-weight-bold">Handphone</label>
                            <input name="handphone" type="number" placeholder="Handphone" class="form-control small" value="{{$kurir->handphone}}">
                            </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold">Nama</label>
                          <input name="name" type="text" class="form-control small" placeholder="Masukkan Nama Anda..." value="{{$kurir->name}}">
                          </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="drop_point" class="small font-weight-bold">Drop Point</label>
                                    <select name="drop_id" id="drop_point" class="form-control">
                                        @foreach ($dropPoint as $dropPoint)
                                        <option value="{{$dropPoint->id}}">{{$dropPoint->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                              </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold" for="address">Alamat</label>
                          <textarea name="address" id="address"  rows="6" class="small form-control">{{$kurir->address}}</textarea>
                          </div>
                        </div>

                        <div class="col-md-6">
                                <div class="form-group">
                                  <label class="small font-weight-bold">Foto</label>
                                  <br>
                                  <div class="fileinput d-block fileinput-exists" data-provides="fileinput">
                                        <div class="fileinput-new img-thumbnail" style="display:none;width: 200px; height: 150px;">
                                        <img src="{{asset('/upload/'.$kurir->drop_id.'/kurir/'.$kurir->nik.'/foto/'. $kurir->foto)}}" alt="...">
                                        </div>
                                        <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px; line-height: 10px;"><img src="{{asset('/upload/'.$kurir->drop_id.'/kurir/'.$kurir->nik.'/foto/'. $kurir->foto)}}" style="max-height: 140px;"></div>
                                        <div>
                                          <span class="btn btn-outline-secondary btn-file"><span class="fileinput-new">Upload Foto</span><span class="fileinput-exists">Ubah</span><input type="hidden" value="{{$kurir->foto}}" name="foto" ><input type="file" name="foto"  value="{{$kurir->foto}}"></span>
                                          <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Hapus</a>
                                        </div>
                                      </div>
                                </div>
                                <div class="form-group">
                                      <label class="small font-weight-bold">KTP</label>
                                      <br>
                                      <div class="fileinput d-block fileinput-exists" data-provides="fileinput">
                                            <div class="fileinput-new img-thumbnail" style="display:none;width: 200px; height: 150px;">
                                            <img src="{{asset('/upload/'.$kurir->drop_id.'/kurir/'.$kurir->nik.'/ktp/'. $kurir->ktp)}}" alt="...">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px; line-height: 10px;"><img src="{{asset('/upload/'.$kurir->drop_id.'/kurir/'.$kurir->nik.'/ktp/'. $kurir->ktp)}}" style="max-height: 140px;"></div>
                                            <div>
                                              <span class="btn btn-outline-secondary btn-file"><span class="fileinput-new">Upload Foto</span><span class="fileinput-exists">Ubah</span><input type="hidden" value="{{$kurir->ktp}}" name="ktp" ><input type="file" name="ktp"  value="{{$kurir->ktp}}"></span>
                                              <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Hapus</a>
                                            </div>
                                          </div>
                                    </div>
                              </div>
                      </div>
                      <button class="btn btn-primary" type="submit">Ubah Data</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
        </div>
@endsection
