@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Settings Fuzzy Rules</h1>
        </div>
        <div class="row">
          <!-- Area Chart -->
          <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Variable & Himpunan</h6>
              </div>
              <!-- Card Body -->
              <div class="card-body">
              <form class="form" action="{{route('updateFuzzyRules')}}" method="POST" >
                @csrf
                {{method_field('PUT')}}
                <div id="rules1" class="form-group row col-12">
                        <div class="col-1 text-center">
                            <span class="badge badge-secondary">[R1]</span>
                            IF</div>
                        <div class="col-3 text-center">
                            <select name="R1_IF" class="form-control" disabled  >
                                <option value="0">
                                    DONATUR SEDIKIT
                                </option>
                                <option value="1">
                                    DONATUR BANYAK
                                </option>
                            </select>
                        </div>
                        <div class="col-1 text-center">ANDS</div>
                        <div class="col-3 text-center">
                                <select name="R1_ANDS" id="" class="form-control" disabled  >

                                        <option value="0">
                                                KURIR SEDIKIT
                                            </option>
                                        <option value="1">
                                            KURIR BANYAK
                                        </option>
                                    </select>
                        </div>
                        <div class="col-1 text-center">THEN</div>
                        <div class="col-3 text-center">
                                <select name="R1_THEN" id="" class="form-control" disabled  >
                                        <option value="0">
                                                REKOMENDASI RENDAH
                                            </option>
                                        <option value="1">
                                           REKOMENDASI TINGGI
                                        </option>

                                    </select>
                        </div>
                    </div>

                    <div id="rules2" class="form-group row col-12">
                            <div class="col-1 text-center">
                                <span class="badge badge-success">[R2]</span>
                                IF</div>
                            <div class="col-3 text-center">
                                <select name="R2_IF" id="" class="form-control" disabled  >
                                    <option value="0">
                                        DONATUR SEDIKIT
                                    </option>
                                    <option value="1">
                                        DONATUR BANYAK
                                    </option>
                                </select>
                            </div>
                            <div class="col-1 text-center">ANDS</div>
                            <div class="col-3 text-center">
                                    <select name="R2_ANDS" id="" class="form-control" disabled  >

                                            <option value="0">
                                                    KURIR SEDIKIT
                                                </option>
                                            <option value="1">
                                                KURIR BANYAK
                                            </option>
                                        </select>
                            </div>
                            <div class="col-1 text-center">THEN</div>
                            <div class="col-3 text-center">
                                    <select name="R2_THEN" id="" class="form-control" disabled  >
                                            <option value="0">
                                                    REKOMENDASI RENDAH
                                                </option>
                                            <option value="1">
                                               REKOMENDASI TINGGI
                                            </option>

                                        </select>
                            </div>
                        </div>

                        <div id="rules3" class="form-group row col-12">
                                <div class="col-1 text-center">
                                    <span class="badge badge-danger">[R3]</span>
                                    IF</div>
                                <div class="col-3 text-center">
                                    <select name="R3_IF" id="" class="form-control" disabled  >
                                        <option value="0">
                                            DONATUR SEDIKIT
                                        </option>
                                        <option value="1">
                                            DONATUR BANYAK
                                        </option>
                                    </select>
                                </div>
                                <div class="col-1 text-center">ANDS</div>
                                <div class="col-3 text-center">
                                        <select name="R3_ANDS" id="" class="form-control" disabled  >

                                                <option value="0">
                                                        KURIR SEDIKIT
                                                    </option>
                                                <option value="1">
                                                    KURIR BANYAK
                                                </option>
                                            </select>
                                </div>
                                <div class="col-1 text-center">THEN</div>
                                <div class="col-3 text-center">
                                        <select name="R3_THEN" id="" class="form-control" disabled  >
                                                <option value="0">
                                                        REKOMENDASI RENDAH
                                                    </option>
                                                <option value="1">
                                                   REKOMENDASI TINGGI
                                                </option>

                                            </select>
                                </div>
                            </div>

                            <div id="rules4" class="form-group row col-12">
                                    <div class="col-1 text-center">
                                        <span class="badge badge-primary">[R4]</span>
                                        IF</div>
                                    <div class="col-3 text-center">
                                        <select name="R4_IF" id="" class="form-control" disabled  >
                                            <option value="0">
                                                DONATUR SEDIKIT
                                            </option>
                                            <option value="1">
                                                DONATUR BANYAK
                                            </option>
                                        </select>
                                    </div>
                                    <div class="col-1 text-center">ANDS</div>
                                    <div class="col-3 text-center">
                                            <select name="R4_ANDS" id="" class="form-control" disabled  >

                                                    <option value="0">
                                                            KURIR SEDIKIT
                                                        </option>
                                                    <option value="1">
                                                        KURIR BANYAK
                                                    </option>
                                                </select>
                                    </div>
                                    <div class="col-1 text-center">THEN</div>
                                    <div class="col-3 text-center">
                                            <select name="R4_THEN" id="" class="form-control" disabled  >
                                                    <option value="0">
                                                            REKOMENDASI RENDAH
                                                        </option>
                                                    <option value="1">
                                                       REKOMENDASI TINGGI
                                                    </option>

                                                </select>
                                    </div>
                                </div>

                    {{-- <div class="form-group col-12 text-center mt-5">
                        <button class="btn btn-primary  " type="button"  >SIMPAN</button>
                    </div> --}}
              </form>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->
@endsection
@section('custom-js')
<script>
$(document).ready(function(){
    $('select[name=R1_IF]').val({{explode(",",$pakarSettings->R1)[0]}});
$('select[name=R1_ANDS]').val({{explode(",",$pakarSettings->R1)[1]}});
$('select[name=R1_THEN]').val({{explode(",",$pakarSettings->R1)[2]}});

$('select[name=R2_IF]').val({{explode(",",$pakarSettings->R2)[0]}});
$('select[name=R2_ANDS]').val({{explode(",",$pakarSettings->R2)[1]}});
$('select[name=R2_THEN]').val({{explode(",",$pakarSettings->R2)[2]}});

$('select[name=R3_IF]').val({{explode(",",$pakarSettings->R3)[0]}});
$('select[name=R3_ANDS]').val({{explode(",",$pakarSettings->R3)[1]}});
$('select[name=R3_THEN]').val({{explode(",",$pakarSettings->R3)[2]}});

$('select[name=R4_IF]').val({{explode(",",$pakarSettings->R4)[0]}});
$('select[name=R4_ANDS]').val({{explode(",",$pakarSettings->R4)[1]}});
$('select[name=R4_THEN]').val({{explode(",",$pakarSettings->R4)[2]}});
});
</script>
@endsection
