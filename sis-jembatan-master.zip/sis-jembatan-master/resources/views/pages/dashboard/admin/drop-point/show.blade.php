@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">{{$dropPoint->name}}</h1>
            </div>

            <div class="row">
                <div class="col-md-4">
                <div class="card shadow">
                        <div class="card-header py-2">
                            Map
                        </div>
                        <div class="card-body">
                            <iframe width="100%" height="200" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?q={{$dropPoint->langtitude}},{{$dropPoint->longtitude}}&amp;key=AIzaSyCNoV504QEhGxE0svdnhqHnYmNrOXakTQo"></iframe>
                        </div>
                    </div>
                </div>
              <div class="col-md-8">
                <!-- Bagian Kartu Ketika Di perbarui -->
                <div class="card shadow mb-4">
                  <div class="card-header py-2">
                    <h6 class="m-0 ">Detail</h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <td>Nama Posko</td>
                            <td>{{$dropPoint->name}}</td>
                            </tr>
                            <tr>
                                    <td>
                                        Handphone
                                    </td>
                                    <td>
                                            {{$dropPoint->handphone}}
                                    </td>
                                </tr>
                            <tr>
                                    <td>
                                        Location
                                    </td>
                                    <td>
                                        {{$dropPoint->address}}
                                    </td>
                                </tr>

                        </table>
                    </div>
                  </div>
                </div>

                <div class="card shadow mb-4">
                    <div class="card-header py-2">
                      <h6 class="m-0 ">Logistik</h6>
                    </div>
                    <div class="card-body">
                      <div class="table-responsive">
                          <table class="table table-striped">
                              <thead>
                                  <tr>
                                      <th>Jenis</th>
                                      <th>Jumlah</th>
                                      <th>Satuan</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  @foreach ($activity as $activity)
                                    <tr>
                                    <td>{{$activity->description_logistic}}</td>
                                    <td>{{$activity->count_logistic}}</td>
                                    <td>{{$activity->satuan_logistic}}</td>
                                    </tr>
                                  @endforeach
                              </tbody>
                          </table>
                      </div>
                    </div>
                  </div>
            </div>
        </div>
    </div>
@endsection
