<header class="header-global">
    <nav id="navbar-main" class="navbar navbar-main navbar-expand-lg navbar-transparent navbar-light headroom">
      <div class="container">
      <a class="navbar-brand mr-lg-5" href="{{url('/')}}">
          <img src="{{asset('/landing/img/logo-text.png')}}" class="img-fluid" style="height:50px">
        </a>
        <div class="dropdown">
                <button class="btn btn-link" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img class="img-fluid rounded-circle" width="35" src="{{asset('landing/img/user.svg')}}" alt="">
                </button>

                @if (Auth::user())
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        @if (Auth::user()->role_id == 0)
                        <a class="dropdown-item bg-primary text-white" href="{{url('/dashboard')}}">DASHBOARD</a>
                        @elseif(Auth::user()->role_id == 1)
                        <a class="dropdown-item bg-primary text-white" href="{{url('/admin')}}">DASHBOARD</a>
                        @elseif(Auth::user()->role_id == 2)
                        <a class="dropdown-item bg-primary text-white" href="{{url('/manager')}}">DASHBOARD</a>
                        @elseif(Auth::user()->role_id == 3)
                        <a class="dropdown-item bg-primary text-white" href="{{url('/pakar')}}">DASHBOARD</a>
                        @endif
                          <a class="dropdown-item" href="{{ route('logout') }}"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            {{ __('Keluar') }}
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            @csrf
                                        </form>
                        </div>
                @else
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item bg-primary text-white" href="{{route('login')}}">Masuk</a>
                        <a class="dropdown-item" href="{{route('register')}}">Datar</a>
                        </div>
                @endif
        </div>
      </div>
    </nav>
  </header>
