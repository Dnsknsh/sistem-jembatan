@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Edit Drop Point</h1>
        </div>


        <div class="row">

          <!-- Area Chart -->
          <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Form Edit Drop Point</h6>
              </div>
              <!-- Card Body -->
              <div class="card-body">
              <form class="form" action="{{route('drop-point.update',$dropPoint->id)}}" method="POST" enctype="multipart/form-data">
                @csrf
                {{method_field('PUT')}}
                <div class="row">
                 <div class="form-group col-12 col-md-6">
                    <label for="name">Nama</label>
                 <input type="text" class="form-control" id="name" placeholder="Nama Drop Point" name="name" value="{{$dropPoint->name}}">
                 </div>
                 <div class="form-group col-12 col-md-6">
                        <label for="handphone">Handphone</label>
                 <input type="text" class="form-control" id="handphone" placeholder="Handphone" name="handphone" value="{{$dropPoint->handphone}}">
                </div>
                <div class="form-group col-12 col-md-6">
                    <label for="namaLogistik">Lokasi</label>
                    <div class="form-control" id="googleMap" style="width:100%;height:350px;"></div>
            </div>

            <div class="form-group col-12 col-md-6">
                    <label for="stok">Alamat</label>
            <textarea name="address" id="address" cols="30" rows="5" class="form-control">{{$dropPoint->address}}</textarea>
            </div>
                <div class="form-group col-12 col-md-6" style="display:none">
                <input type="hidden" id="langtitude"  name="langtitude" value="{{$dropPoint->langtitude}}">
                <input type="hidden" id="longtitude"  name="longtitude" value="{{$dropPoint->longtitude}}">
                <input type="hidden" id="kecamatan"  name="kecamatan" value="{{$dropPoint->kecamatan}}">
                <input type="hidden" id="postal_code" name="kode_pos" value="{{$dropPoint->kode_pos}}">
                </div>
                <div class="form-group col-12 text-center">
                    <button class="btn btn-primary" type="submit">Edit Drop Point</button>
                </div>
                </div>
              </form>
              </div>
            </div>
          </div>

          <!-- Pie Chart -->
          <div class="col-xl-4 col-lg-5">

            <!-- Approach -->
            <div class="card shadow mb-4">
              <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">PENGUMUMAN</h6>
              </div>
              <div class="card-body">
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus consequatur nisi, alias adipisci nulla sequi, laboriosam quisquam consectetur, incidunt nihil fuga ducimus? Maiores cupiditate, quae laborum molestiae culpa magnam dolores.</p>
              </div>
            </div>

          </div>
        </div>

      </div>
      <!-- /.container-fluid -->
@endsection
@section('custom-js')
<script>
// variabel global marker
var marker,infoWindow;
      function taruhMarker(peta, posisiTitik){
          if( marker ){
            // pindahkan marker
            marker.setPosition(posisiTitik);
          } else {
            // buat marker baru
            marker = new google.maps.Marker({
              position: posisiTitik,
              map: peta
            });
          }
              convert_latlng(posisiTitik);
           // isi nilai koordinat ke form
          document.getElementById("langtitude").value = posisiTitik.lat();
          document.getElementById("longtitude").value = posisiTitik.lng();
      }
      // merubah geotag menjadi alamat
      function convert_latlng(pos) {
       // membuat geocoder
      var geocoder = new google.maps.Geocoder();
       geocoder.geocode({'latLng': pos}, function(r) {
        if (r && r.length > 0) {
            function placeToAddress(place){
        var address = {};
        place.address_components.forEach(function(c) {
            switch(c.types[0]){
                case 'administrative_area_level_3':     //  Note some countries don't have states
                    address.kec = c;
                    break;
                case 'postal_code':
                    address.Zip = c;
                    break;
            }
        });

        return address;
    }
        var str = placeToAddress(r[0]).kec.short_name;
        var res = str.slice(4, str.length);
        document.getElementById('kecamatan').value = res;
        document.getElementById('postal_code').value = placeToAddress(r[0]).Zip.short_name;
        document.getElementById('address').value = r[0].formatted_address;
        } else {
         document.getElementById('address').value = 'Alamat tidak di temukan di lokasi !!';
        }
       });
      }
      function initialize() {
        var propertiPeta = {
          center:new google.maps.LatLng(-7.687466468355338,110.41204980722989),
          zoom:15,
          mapTypeId:google.maps.MapTypeId.ROADMAP,
          mapTypeControl: true,
          streetViewControl: false,
        };
        var peta = new google.maps.Map(document.getElementById("googleMap"), propertiPeta);
        // even listner ketika peta diklik
        google.maps.event.addListener(peta, 'click', function(event) {
          taruhMarker(this, event.latLng);
        });
      }
      // event jendela di-load
      google.maps.event.addDomListener(window, 'load', initialize);
</script>
@endsection
