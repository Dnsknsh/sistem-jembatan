@extends('layouts.dashboard.master')
@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Donasi Saya</h1>
        <!-- DataTales Example -->
        <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Donasi Saya</h6>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                          <th>Title</th>
                          <th>Lokasi Penjemputan</th>
                          <th>Jenis Donasi</th>
                          <th>Jumlah</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tfoot>
                              <th>title</th>
                              <th>Lokasi Penjemputan</th>
                              <th>Jenis Donasi</th>
                              <th>Jumlah</th>
                              <th>Status</th>
                              <th>Action</th>
                      </tfoot>
                      <tbody>

                              @foreach ($ownDonation as $ownDonation)
                              <tr>
                              <td>{{$ownDonation->Donation['title']}}</td>
                              <td>

                                      @if ($ownDonation->category == "money")
                                          Transfer
                                      @elseif($ownDonation->category == "logistic")
                                      <iframe width="100%" height="200" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?q={{$ownDonation->langtitude}},{{$ownDonation->longtitude}}&amp;key=AIzaSyCNoV504QEhGxE0svdnhqHnYmNrOXakTQo"></iframe>
                                      @endif

                              </td>
                                  <td>
                                      @if ($ownDonation->category== "money")
                                      Uang
                                      @elseif($ownDonation->category == "logistic")
                                      Logistik
                                      @endif
                                  </td>
                                      <td>
                                          @if ($ownDonation->category == "money")
                                          Rp.{{$ownDonation->count_money}}
                                          @elseif($ownDonation->category == "logistic")

                                          @if ($ownDonation->count_logistic)
                                          {{$ownDonation->count_logistic}}({{$ownDonation->satuan_logistic}})
                                          @else
                                          Belum dihitung
                                          @endif
                                          @endif
                                      </td>
                                      <td>
                                          @if ($ownDonation->status == 0)
                                              <span class="badge badge-secondary">Sedang Mencari Kurir Terdekat</span>
                                          @elseif($ownDonation->status == 1)
                                              <span class="badge badge-primary">Kurir Ditemukan</span>
                                          @elseif($ownDonation->status == 2)
                                          <span class="badge badge-success">Sudah Dijemput</span>
                                          @elseif($ownDonation->status == 3)
                                          <span class="badge badge-success">Sudah di Gudang Logistik Pusat</span>
                                          @elseif($ownDonation->status == 4)
                                          <span class="badge badge-success">Terbayar</span>
                                          @endif
                                      </td>
                                      <td>
                                          @if ($ownDonation->category == "money")
                                              -
                                        @elseif($ownDonation->category == "logistic")
                                        <div class="d-flex">
                                                @if ($ownDonation->drop_id && $ownDonation->kurir_id)
                                                <button onclick="location.href='{{route('detailOwnDonation',$ownDonation->id)}}'" class="btn btn-primary btn-icon-split mr-2">
                                                        <span class="icon text-white-50">
                                                                  <i class="fas fa-eye"></i>
                                                                </span>
                                                </button>
                                                @else
                                                <a href="#" data-toggle="modal" data-target="#findKurirModal" class="btn btn-primary btn-icon-split mr-2"><span class="icon text-white-50">
                                                        <i class="fas fa-eye"></i>
                                                      </span></a>
                                                @endif
                                        </div>
                                          @endif
                                    </td>
                                  </tr>
                              @endforeach

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

      </div>
      <!-- /.container-fluid -->
@endsection
