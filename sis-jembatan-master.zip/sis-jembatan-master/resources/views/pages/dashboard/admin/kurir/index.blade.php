@extends('layouts.dashboard.master')
@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Daftar Kurir</h1>
        <p class="mb-4">Berikut merupakan daftar list Kurir .</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Kurir</h6>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Foto</th>
                    <th>Nama</th>
                    <th>Nomor HP</th>
                    <th>Drop Point</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tfoot>
                  <th>Foto</th>
                  <th>Nama</th>
                  <th>Nomor HP</th>
                  <th>Drop Point</th>
                  <th>Action</th>
                </tfoot>
                <tbody>
                  @foreach ($kurir as $kurir)
                  <tr>
                  <td><img class="img-fluid" width="150" src="{{asset('/upload/'.$kurir->drop_id.'/kurir/'.$kurir->nik.'/foto/'.$kurir->foto)}}" alt=""></td>
                  <td>{{$kurir->name}}</td>
                  <td>{{$kurir->handphone}}</td>
                  <td>{{$kurir->DropPoint['name']}}</td>
                        <td>
                        <div class="d-flex">
                                <button onclick="location.href='{{route('kurir.show',$kurir->id)}}'" class="btn btn-primary btn-icon-split mr-2">
                                        <span class="icon text-white-50">
                                                  <i class="fas fa-eye"></i>
                                                </span>
                                </button>
                                  {{-- <button onclick="location.href='{{route('kurir.edit',$kurir->id)}}'" class="btn btn-success btn-icon-split mr-2">
                                    <span class="icon text-white-50">
                                      <i class="fas fa-edit"></i>
                                    </span>
                                </button> --}}
                                <form action="{{route('kurir.destroy',$kurir->id)}}" method="post">
                                    @csrf
                                    {{method_field('DELETE')}}
                                <input type="hidden" name="drop_id" value="{{$kurir->DropPoint['id']}}">
                                    <button type="submit" class="btn btn-danger btn-icon-split">
                                            <span class="icon text-white-50">
                                              <i class="fas fa-trash"></i>
                                            </span>
                                    </button>
                                </form>
                        </div>
                        </td>
                      </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->
@endsection
