@extends('layouts.landing.master')
@section('title', 'Yuk Donasi !')
@section('main')
@include('components.landing.header')

<main>
	<div class="position-relative">
		<!-- Hero for FREE version -->
		<section class="section section-lg section-hero section-shaped">
			<!-- Background circles -->
			<div class="shape shape-style-1 shape-primary">
				<span class="span-150"></span>
				<span class="span-50"></span>
				<span class="span-50"></span>
				<span class="span-75"></span>
				<span class="span-100"></span>
				<span class="span-75"></span>
				<span class="span-50"></span>
				<span class="span-100"></span>
				<span class="span-50"></span>
				<span class="span-100"></span>
			</div>
			<div class="container shape-container d-flex align-items-center py-lg">
				<div class="col px-0">
					<div class="row align-items-center justify-content-center">
						<div class="col-lg-6 text-center">
							<img src="{{asset('landing/img/Logo.png')}}" style="width: 300px;" class="img-fluid">
								<p class="lead text-white">sistem jembatan atau sistem jemput bantuan adalah suatu sistem pelayanan jemput bantuan donasi baik berupa uang tunai maupun barang logistik.</p>
								<div class="btn-wrapper mt-5">
									<a href="#featured" class="btn btn-lg btn-white btn-icon mb-3 mb-sm-0">
										<span class="btn-inner--icon">
											<i class="ni ni-money-coins"></i>
										</span>
										<span class="btn-inner--text">Donasi Sekarang!</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="separator separator-bottom separator-skew">
					<svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1"
						xmlns="http://www.w3.org/2000/svg">
						<polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
					</svg>
				</div>
			</section>
		</div>
		<section class="section section-md pt-lg-0 mt--100" id="section-components">
			<div class="container">
				<div class="row row-grid justify-content-center">
					<div class="col-lg-4">
						<div class="card card-lift--hover shadow border-0">
							<div class="card-body py-5">
                            <h3>{{$donation->count()}}</h3>
								<h6 class="text-warning text-uppercase">Donasi dibuka</h6>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="card card-lift--hover shadow border-0">
							<div class="card-body py-5">
								<h3>Rp.{{number_format($allCount)}}</h3>
								<h6 class="text-warning text-uppercase">Donasi Tersalurkan</h6>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="card card-lift--hover shadow border-0">
							<div class="card-body py-5">
								<h3>{{$donatur_count}}</h3>
								<h6 class="text-warning text-uppercase">Donatur Terdaftar</h6>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="section section-lg">
			<div class="container">
				<div class="row row-grid align-items-center">
					<div class="col-md-6 order-md-1 ">
						<div class="pr-md-5">
							<div class="icon icon-lg icon-shape icon-shape-success shadow rounded-circle mb-5">
								<i class="ni ni-satisfied"></i>
							</div>
							<h3>Cara Berdonasi</h3>
							<p>Anda dapat berdonasi dengan mudah di sistem jemput bantuan</p>
							<ul class="list-unstyled mt-5">
								<li class="py-2">
									<div class="d-flex align-items-center">
										<div>
											<div class="badge badge-circle badge-success mr-3">
                              1
                            </div>
										</div>
										<div>
											<h6 class="mb-0">Pilih Campaign yang ingin anda bantu.</h6>
										</div>
									</div>
								</li>
								<li class="py-2">
									<div class="d-flex align-items-center">
										<div>
											<div class="badge badge-circle badge-primary mr-3">
                              2
                            </div>
										</div>
										<div>
											<h6 class="mb-0">Pilih Kategori Donasi</h6>
										</div>
									</div>
								</li>
								<li class="py-2">
									<div class="d-flex align-items-center">
										<div>
											<div class="badge badge-circle badge-warning mr-3">
                              3
                            </div>
										</div>
										<div>
											<h6 class="mb-0">Silahkan transfer sesuai nominal atau minta kurir menjemput bantuan anda</h6>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-md-6 order-md-2">
						<img src="{{asset('landing/img/how-to.png')}}" class="img-fluid floating">
						</div>
					</div>
				</div>
			</section>

    @include('components.landing.featured')

			<section class="section section-components pb-0" id="section-components">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-12">
							<!-- Basic elements -->
							<h2 class="mb-5">
								<span>Yuk Donasi Sekarang!</span>
							</h2>
						</div>
					</div>
					<div class="row justify-content-center mb-5">
                    @foreach($donation as $donation)
                       @if ($donation->status == 1)
                       <div class="col-12 col-lg-4 mt-4">
                            <a href="{{route('campaign',$donation->id)}}" style="color:#212529">
                                <div class="card shadow">
                                    <img class="img-fluid rounded" src="{{asset('/upload/donation/'.$donation->title.'_'.$donation->startDate.'/'.$donation->thumbnail)}}" alt="">
                                    <div class="card-body">
                                        <strong>{{$donation->title}}</strong>
                                        <br>
                                        <span class="badge badge-pill badge-primary">{{$donation->location}}</span>
                                        @if ($donation->acc_logistic == "on")
                                        <span class="badge badge-pill badge-warning"><i class="fa fa-truck"></i></span>
                                        @endif
                                        @if($donation->acc_money == "on")
                                        <span class="badge badge-pill badge-success"><i class="fa fa-money"></i></span>
                                        @endif
                                        <div class="progress mt-2">
                                            <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-8">
                                                <small>
                                                   Mulai<br>{{date('d-m-Y', strtotime($donation->startDate))}}
                                                </small>
                                            </div>
                                            <div class="col-4 text-right">
                                                <small>Selesai<br>{{date('d-m-Y', strtotime($donation->endDate))}}</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                       @endif
                    @endforeach
				    </div>
					{{-- <div class="row mt-5 mb-5">
						<div class="col-12 text-center">
							<button type="button" class="btn btn-primary">Lihat Semua Donasi</button>
						</div>
					</div> --}}
				</div>
			</section>
	</main>
  @include('components.landing.footer')
@endsection
