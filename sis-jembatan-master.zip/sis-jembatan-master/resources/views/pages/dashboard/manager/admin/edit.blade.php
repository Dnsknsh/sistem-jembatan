@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Edit admin</h1>
            </div>

            <div class="row">
              <div class="col-md-12">


                <!-- Bagian Kartu Ketika Di perbarui -->

                <div class="card shadow mb-4">
                  <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold">Biodata admin</h6>
                  </div>
                  <div class="card-body">
                    <form action="{{route('admin.update',$admin->id)}}" method="POST">
                    @csrf
                    {{method_field('PUT')}}
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="role" class="small font-weight-bold">Nama</label>
                                <input name="name" type="text" placeholder="Masukan Nama Admin..." class="form-control small" value="{{$admin->name}}">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="role" class="small font-weight-bold">Handphone</label>
                                <input name="handphone" type="number" placeholder="Handphone" class="form-control small" value="{{$admin->handphone}}">
                            </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold">Email</label>
                            <input name="email" type="text" class="form-control small" placeholder="Masukkan Email Admin..." value="{{$admin->email}}" >
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold">Password</label>
                            <input name="password" type="password" class="form-control small" placeholder="Masukkan Password Admin..." value="{{$admin->password}}" >
                          </div>
                        </div>
                        
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold" for="address">Alamat</label>
                            <textarea name="address" id="address"  rows="6" class="small form-control">{{$admin->address}}</textarea>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold">Ulangi Password</label>
                            <input type="password" class="form-control small" placeholder="Ulangi Password Admin..." value="{{$admin->password}}" >
                          </div>
                          <div class="form-group">
                            <label class="small font-weight-bold">Foto</label>
                            <br>
                            <input type="file" name="foto" class="form-control-file">
                          </div>
                        </div>
                      </div>
                      <button class="btn btn-primary" type="submit">Ubah Data</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
        </div>
@endsection
