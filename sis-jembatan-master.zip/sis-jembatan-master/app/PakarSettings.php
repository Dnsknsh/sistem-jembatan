<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PakarSettings extends Model
{
    //
}
