@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Edit Profile</h1>
        </div>
        <div class="row">
          <!-- Area Chart -->
          <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Edit Profile</h6>
              </div>
              <!-- Card Body -->
              <div class="card-body">
              <form class="form" action="{{route('updatePakar')}}" method="POST" enctype="multipart/form-data">
                @csrf
                {{method_field('PUT')}}
                <div class="row">

                 <div class="form-group col-12 col-md-6">
                    <label for="name">Nama</label>
                 <input type="text" class="form-control" id="name" placeholder="Nama" name="name" value="{{$pakar->name}}">
                 </div>
                 <div class="form-group col-12 col-md-6">
                        <label for="email">Email</label>
                 <input type="email" class="form-control" id="email" placeholder="Email" name="email" value="{{$pakar->email}}">
                </div>
                <div class="form-group col-12 col-md-6">
                    <label for="handphone">Handphone</label>
                <input type="number" class="form-control" id="handphone" placeholder="Handphone" name="handphone" value="{{$pakar->handphone}}">
            </div>
            <div class="form-group col-12 col-md-6">
                    <label for="password">Password Baru</label>
                    <input type="password" class="form-control" id="password" placeholder="Password" name="password">
            </div>
            <div class="form-group col-12 col-md-6">
                    <label for="namaLogistik">Foto</label>
                   @if ($pakar->foto)
                   <div class="fileinput d-block fileinput-exists" data-provides="fileinput">
                        <div class="fileinput-new img-thumbnail" style="display:none;width: 200px; height: 150px;">
                        <img src="{{asset('/upload/pakar/'.$pakar->email.'/'.$pakar->foto)}}" alt="...">
                        </div>
                        <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px; line-height: 10px;"><img src="{{asset('/upload/pakar/'.$pakar->email.'/'.$pakar->foto)}}" style="max-height: 140px;"></div>
                        <div>
                          <span class="btn btn-outline-secondary btn-file"><span class="fileinput-new">Upload Foto</span><span class="fileinput-exists">Ubah</span><input type="hidden" value="{{$pakar->foto}}" name="foto" ><input type="file" name="foto"  value="{{$pakar->foto}}"></span>
                          <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Hapus</a>
                        </div>
                      </div>
                   @else
                   <div class="fileinput fileinput-new d-block" data-provides="fileinput">
                        <div class="fileinput-new img-thumbnail" style="display:none;width: 200px; height: 150px;">
                          <img data-src=""  alt="...">
                        </div>
                        <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px;"></div>
                        <div>
                          <span class="btn btn-outline-secondary btn-file"><span class="fileinput-new">Upload Foto</span><span class="fileinput-exists">Ubah</span><input type="file" name="foto"></span>
                          <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Hapus</a>
                        </div>
                      </div>
                   @endif
                 </div>
                 <div class="form-group col-12 col-md-6">
                        <label for="gender">Jenis Kelamin</label>
                        <select name="gender" class="form-control" id="gender">
                            <option value="laki-laki">Laki-Laki</option>
                            <option value="perempuan">Perempuan</option>
                        </select>
                    </div>
                <div class="form-group col-12 col-md-12">
                        <label for="alamat">Alamat</label>
                <textarea name="address" id="" cols="30" rows="5" class="form-control">{{$pakar->address}}</textarea>
                    </div>
                <div class="form-group col-12 text-center mt-5">
                    <button class="btn btn-primary" type="submit">Ubah Data</button>
                </div>
                </div>
              </form>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->
@endsection
