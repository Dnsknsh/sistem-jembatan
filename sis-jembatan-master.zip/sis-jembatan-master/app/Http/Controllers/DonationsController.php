<?php

namespace App\Http\Controllers;

use App\Donations;
use App\DonationsActivity;
use Illuminate\Http\Request;

class DonationsController extends Controller
{

    public function index()
    {
        $donation = Donations::all();
        return view('pages.dashboard.admin.donation.index',compact('donation'));
    }


    public function create()
    {
        return view('pages.dashboard.admin.donation.add');
    }


    public function store(Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
            'startDate'=>'required',
            'endDate' => 'required',
            'thumbnail.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',

        ]);
        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }

        $donation = new Donations;
        $donation->title = $request->title;
        $donation->description = $request->description;
        $donation->location = $request->location;
        $donation->endDate = $request->endDate;
        $donation->startDate = $request->startDate;
        $donation->status = 0;
        if ($request->acc_money) {
            $donation->acc_money = $request->acc_money;
        }
        if ($request->acc_logistic) {
            $donation->acc_logistic = $request->acc_logistic;
        }
        if($request->hasfile('thumbnail')){
            $image_thumbnail=  $request->file('thumbnail');
            $name_thumbnail=generateRandomString().'.'.$image_thumbnail->getClientOriginalExtension();
            $image_thumbnail->move(public_path().'/upload/donation/'.$donation->title.'_'.$donation->startDate.'/', $name_thumbnail);
            $data_thumbnail = $name_thumbnail;
        }
        if($request->hasfile('thumbnail'))
        {
            $donation->thumbnail=$data_thumbnail;
        }
        $donation->save();

        return redirect()->route('donation.index')->with('success','Berhasil membuat Pengajuan Kampanye Donasi');
    }

    public function show($id)
    {
        $activity = DonationsActivity::where('don_id',$id)->get();
        $donation = Donations::find($id);
        return view('pages.dashboard.admin.donation.show',compact('donation','activity'));
    }


    public function edit($id)
    {
        $donation = Donations::find($id);

        return view('pages.dashboard.admin.donation.edit',compact('donation'));
    }


    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
            'startDate'=>'required',
            'endDate' => 'required',
            'thumbnail.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',

        ]);
        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }

        $donation = Donations::find($id);
        $donation->title = $request->title;
        $donation->description = $request->description;
        $donation->location = $request->location;
        $donation->endDate = $request->endDate;
        $donation->startDate = $request->startDate;
        if ($request->acc_money) {
            $donation->acc_money = $request->acc_money;
        }
        if ($request->acc_logistic) {
            $donation->acc_logistic = $request->acc_logistic;
        }
        if($request->hasfile('thumbnail')){
            $image_thumbnail=  $request->file('thumbnail');
            $name_thumbnail=generateRandomString().'.'.$image_thumbnail->getClientOriginalExtension();
            $image_thumbnail->move(public_path().'/upload/donation/'.$donation->title.'_'.$donation->startDate.'/', $name_thumbnail);
            $data_thumbnail = $name_thumbnail;
        }
        if($request->hasfile('thumbnail'))
        {
            $donation->thumbnail=$data_thumbnail;
        }
        $donation->save();

        return redirect()->route('donation.index')->with('success','Berhasil Mengubah Data Kampanye Donasi');
    }


    public function destroy($id)
    {
        $donation = Donations::find($id);
        $donation->delete();

        return redirect()->back()->with('success', 'Berhasil Menghapus Donasi');
    }
}
