<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fuzzy extends Model
{
    //
}
