<?php


Route::get('/', 'landingController@index');
Route::get('/campaign/{id}','landingController@showDonation')->name('campaign');
Route::resource('/give-donation','DonationsActivityController');


//Donatur
Route::prefix('dashboard')->group(function () {
    Route::get('/', 'HomeController@dashboardDonatur')->name('dashboardDonatur');
    Route::get('/my-donation','DonationsActivityController@showOwn')->name('ownDonation');
    Route::get('/my-donation/{id}','DonationsActivityController@detailOwn')->name('detailOwnDonation');
    Route::get('/settings','HomeController@settingsDonatur')->name('settingsDonatur');
    Route::PUT('/settings','HomeController@updateDonatur')->name('updateDonatur');
});

//Admin
Route::prefix('admin')->group(function () {

    Route::get('/','HomeController@dashboardAdmin')->name('dashboardAdmin');
    Route::get('/settings','HomeController@settingsAdmin')->name('settingsAdmin');
    Route::PUT('/settings','HomeController@updateAdmin')->name('updateAdmin');
    Route::resource('kurir', 'CourierController');
    Route::resource('donation','DonationsController');
    Route::resource('donatur','UserController');
    Route::resource('drop-point','DropPointsController');
});

Route::prefix('data')->group(function(){
    Route::get('/activity/{id}','DataController@showActivity');
});

//Manager
Route::prefix('manager')->group(function () {
    // Route::get('/', function(){
    //     return view('pages.dashboard.manager.index');
    // });
    Route::get('/','HomeController@dashboardManager')->name('dashboardManager');
    // Route::get('/','HomeController@dashboardManager')->name('dashboardManager');
    Route::resource('admin', 'AdminController');
    Route::resource('donationManager','VerifDonationsController');
    Route::put('/donation/{donation}','VerifDonationsController@verification')->name('verification');
    Route::get('/settings','HomeController@settingsManager')->name('settingsManager');
    Route::PUT('/settings','HomeController@updateManager')->name('updateManager');
});

//Pakar
Route::prefix('pakar')->group(function () {
    Route::get('/','HomeController@dashboardPakar')->name('dashboardPakar');
    Route::get('/settings','HomeController@settingsPakar')->name('settingsPakar');
    Route::PUT('/settings','HomeController@updatePakar')->name('updatePakar');
    Route::get('/fuzzy/variable','PakarController@fuzzyVariable')->name('fuzzyVariablePakar');
    Route::get('/fuzzy/rules','PakarController@fuzzyRules')->name('fuzzyRulesPakar');
    Route::PUT('/fuzzy/variable','PakarController@updateFuzzyVariable')->name('updateFuzzyVariable');
    Route::PUT('/fuzzy/rules','PakarController@updateFuzzyRules')->name('updateFuzzyRules');
});


Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

