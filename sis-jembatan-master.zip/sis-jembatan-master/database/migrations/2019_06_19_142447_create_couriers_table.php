<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCouriersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('couriers', function (Blueprint $table) {
            $table->Increments('id');
            $table->Integer('drop_id')->unsigned()->index();
            $table->bigInteger('nik')->unique();
            $table->string('name');
            $table->string('handphone');
            $table->text('address');
            $table->string('ktp');
            $table->string('foto');
            $table->timestamps();
            $table->foreign('drop_id')
                    ->references('id')
                    ->on('drop_points')
                    ->onDelete('CASCADE')
                    ->onUpdate('CASCADE');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('couriers');
    }
}
