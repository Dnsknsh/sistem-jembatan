<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DonationsActivity;

class DataController extends Controller
{
    public function showActivity($id){
        $activity = DonationsActivity::find($id);
        $donation = $activity->Donation;
        return response()->json([
            'error' => false,
            'activity'  => $activity,
            'donation' => $donation,
        ], 200);
    }
}
