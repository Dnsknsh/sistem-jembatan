<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDropPointsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('drop_points', function (Blueprint $table) {
            $table->Increments('id');
            $table->string('name');
            $table->string('handphone');
            $table->text('address')->nullable();
            $table->string('langtitude');
            $table->string('longtitude');
            $table->string('kecamatan')->nullable();
            $table->string('kode_pos')->nullable();
            $table->integer('jumlah_kurir')->default(0);
            $table->integer('jumlah_donatur')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('drop_points');
    }
}
