@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">{{$donation->title}}</h1>
            </div>

            <div class="row">
                <div class="col-md-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-2">
                        Thumbnail
                    </div>
                    <div class="card-body">
                            <img src="{{asset('/upload/donation/'.$donation->title.'_'.$donation->startDate.'/'.$donation->thumbnail)}}" class="img-fluid"  alt="">
                    </div>
                </div>
                <div class="card shadow mb-4">
                        <div class="card-header py-2">
                            Activity
                        </div>
                        <div class="card-body">
                                <ul class="list-group mb-5">
                                        @foreach ($activity as $activity)
                                        <li class="list-group-item">

                                                @if ($activity->category == "money")
                                                <strong>{{$activity->User['name']}}</strong> Telah Mendonasikan Uang Sebesar Rp.{{$activity->count_money}}
                                                @elseif($activity->category == "logistic")
                                                <strong>{{$activity->User['name']}}</strong> Telah Mendonasikan {{$activity->description_logistic}}
                                                @endif
                                            </li>
                                        @endforeach
                                    </ul>
                        </div>
                    </div>

                </div>
              <div class="col-md-8">

                <!-- Bagian Kartu Ketika Di perbarui -->

                <div class="card shadow mb-4">
                  <div class="card-header py-2">
                    <h6 class="m-0 ">Detail</h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <td>Judul</td>
                            <td>{{$donation->title}}</td>
                            </tr>
                            <tr>
                                    <td>
                                        Location
                                    </td>
                                    <td>
                                        {{$donation->location}}
                                    </td>
                                </tr>
                                <tr>
                                        <td>
                                            Status
                                        </td>
                                        <td>
                                                @if ($donation->status == 0)
                                                <span class="badge badge-secondary">Belum di setujui</span>
                                            @elseif($donation->status == 1)
                                                <span class="badge badge-success">Aktif</span>
                                            @elseif($donation->status == 2)
                                            <span class="badge badge-danger">Tidak Di Setujui</span>
                                            @endif
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Mulai</td>
                                    <td>{{$donation->startDate}}</td>
                                    </tr>
                                    <tr>
                                        <td>Berakhir</td>
                                    <td>{{$donation->endDate}}</td>
                                    </tr>
                            <tr>
                                <td>
                                    Description
                                </td>
                                <td>
                                    {{$donation->description}}
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Accept Money
                                </td>
                                <td>
                                        @if ($donation->acc_money == "on")
                                        <i class="fa fa-check"></i>
                                        @else
                                        <i class="fa fa-times"></i>
                                        @endif
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Accept Logistic
                                </td>
                                <td>
                                        @if ($donation->acc_logistic == "on")
                                        <i class="fa fa-check"></i>
                                        @else
                                        <i class="fa fa-times"></i>
                                        @endif
                                </td>
                            </tr>
                        </table>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
@endsection
