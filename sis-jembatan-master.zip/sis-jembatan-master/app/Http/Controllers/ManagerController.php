<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\DonationsActivity;
use App\Couriers;
use App\DropPoints;
use App\User;
use App\Donations;
use App\Fuzzy;
class ManagerController extends Controller
{

    // public function index()
    // {
    //         $kurir = Couriers::all();
    //         $posko = DropPoints::all();
    //         $donatur = User::where('role_id',0)->get();
    //         $donation = Donations::where('status',1)->get();
    //         return view('pages.dashboard.manager.index',compact('kurir','posko','donatur','donation'));
    // }

    // public function chartjs()
    // {
    //         // $donasi = DB::table('donations_activities')
    //         //                 ->whereMonth('created_at', '07')
    //         //                 ->get();
    //         $donasi = DonationsActivity::whereMonth('create_at')
    //                         ->groupBy('month', 'data')
    //                         ->get();

    //         // $click = Click::select(DB::raw("SUM(numberofclick) as count"))
    //         //     ->orderBy("created_at")
    //         //     ->groupBy(DB::raw("year(created_at)"))
    //         //     ->get()->toArray();
    //         // $click = array_column($click, 'count');
    //         return $donasi;
    // }


}
