<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\PakarSettings;
use App\Fuzzy;

class PakarController extends Controller
{
    public function fuzzyVariable(){
        $pakarSettings = PakarSettings::first();
        return view('pages.dashboard.pakar.fuzzy.variable',compact('pakarSettings'));
    }

    public function fuzzyRules(){
        $pakarSettings = PakarSettings::first();
        return view('pages.dashboard.pakar.fuzzy.rules',compact('pakarSettings'));
    }
    public function updateFuzzyRules(Request $request){
        $R1['IF'] = $request->R1_IF;
        $R1['ANDS'] = $request->R1_ANDS;
        $R1['THEN'] = $request->R1_THEN;
        $R2['IF'] = $request->R2_IF;
        $R2['ANDS'] = $request->R2_ANDS;
        $R2['THEN'] = $request->R2_THEN;
        $R3['IF'] = $request->R3_IF;
        $R3['ANDS'] = $request->R3_ANDS;
        $R3['THEN'] = $request->R3_THEN;
        $R4['IF'] = $request->R4_IF;
        $R4['ANDS'] = $request->R4_ANDS;
        $R4['THEN'] = $request->R4_THEN;

        $pakarSettings = PakarSettings::first();
        $pakarSettings->R1 = implode(",",array($R1['IF'],$R1['ANDS'],$R1['THEN']));
        $pakarSettings->R2 = implode(",",array($R2['IF'],$R2['ANDS'],$R2['THEN']));
        $pakarSettings->R3 = implode(",",array($R3['IF'],$R3['ANDS'],$R3['THEN']));
        $pakarSettings->R4 = implode(",",array($R4['IF'],$R4['ANDS'],$R4['THEN']));
        $pakarSettings->save();
        return redirect()->back()->with('success','Berhasil Mengubah Rules');
    }

    public function updateFuzzyVariable(Request $request){

        $donaturBanyak['batasAtas'] = $request->donaturBanyak_batasAtas;
        $donaturBanyak['batasBawah'] = $request->donaturBanyak_batasBawah;
        $donaturSedikit['batasAtas'] = $request->donaturSedikit_batasAtas;
        $donaturSedikit['batasBawah'] = $request->donaturSedikit_batasBawah;
        $kurirBanyak['batasAtas'] = $request->kurirBanyak_batasAtas;
        $kurirBanyak['batasBawah'] = $request->kurirBanyak_batasBawah;
        $kurirSedikit['batasAtas'] = $request->kurirSedikit_batasAtas;
        $kurirSedikit['batasBawah'] = $request->kurirSedikit_batasBawah;
        $pakarSettings = PakarSettings::first();
        $pakarSettings->donaturBanyak = json_encode($donaturBanyak);
        $pakarSettings->donaturSedikit = json_encode($donaturSedikit);
        $pakarSettings->kurirBanyak = json_encode($kurirBanyak);
        $pakarSettings->kurirSedikit = json_encode($kurirSedikit);
        $pakarSettings->save();

        function fuzzyTsukamoto($xDonatur, $xKurir){

            $pakarSettings = PakarSettings::first();

            if($xDonatur <= number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah)){

                $phiDonaturBanyak = 0;
                $phiDonaturSedikit = 0;

            }else if($xDonatur >= number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah) || $xDonatur <= number_format(json_decode($pakarSettings->donaturBanyak)->batasAtas)){

            //Keanggotaan Donatur Banyak
            $phiDonaturBanyak = ($xDonatur - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah)) / (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah));

            //Keanggotaan Donatur Sedikit
            $phiDonaturSedikit = (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - $xDonatur) / (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah));

            }else if($xDonatur >= number_format(json_decode($pakarSettings->donaturBanyak)->batasAtas)){
                $phiDonaturBanyak = 1;
                $phiDonaturSedikit = 1;
            }

            if($xKurir <= number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah)){

                $phiKurirBanyak = 0;
                $phiKurirSedikit = 0;

            }else if($xKurir >= number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah) || $xKurir <= number_format(json_decode($pakarSettings->kurirBanyak)->batasAtas)){


            //Keanggotaan Kurir Sedikit
            $phiKurirSedikit = (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - $xKurir) / (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah));
            //Keanggotaan Kurir Banyak
            $phiKurirBanyak = ($xKurir - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah)) / (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah));

            }else if($xKurir >= number_format(json_decode($pakarSettings->kurirBanyak)->batasAtas)){
                $phiKurirBanyak = 1;
                $phiKurirSedikit = 1;
            }

    //IF DONATUR BANYAK DAN KURIR BANYAK MAKA REKOMENDASI TINGGI
    $r1 = min($phiDonaturBanyak , $phiKurirBanyak);
    //IF DONATUR BANYAK DAN KURIR SEDIKIT MAKA REKOMENDASI TINGGI
    $r2 =min($phiDonaturBanyak , $phiKurirSedikit);
    //IF DONATUR SEDIKIT DAN KURIR BANYAK MAKA REKOMENDASI RENDAH
    $r3 =min($phiDonaturSedikit , $phiKurirBanyak);
    //IF DONATUR SEDIKIT DAN KURIR SEDIKIT MAKA REKOMENDASI RENDAH
    $r4 =min($phiDonaturSedikit , $phiKurirSedikit);


    //Cari nilai z1 lihat himpunan TINGGI:
    $z1 = ($r1*100) + 0;
    //Cari nilai z2  lihat himpunan TINGGI:
    $z2 = ($r2*100) + 0;
    //Cari nilai z3 lihat himpunan RENDAH
    $z3= 100 - ($r3*100);
    //Cari nilai z4 lihat himpunan RENDAH:
    $z4 = 100 - ($r4*100);

    if($r1 + $r2 + $r3 + $r4 == 0){
        return 0;
    }else {
        $defuzzifikasi = ( ($r1*$z1) +  ($r2*$z2) +  ($r3*$z3) +  ($r4*$z4)) / ( $r1 + $r2 + $r3 + $r4);
        return $defuzzifikasi;
    }


        }

        $fuzzyData=Fuzzy::all();
        foreach($fuzzyData as $data){
            $data->persentase_rekomendasi = fuzzyTsukamoto($data->jumlah_donatur,$data->jumlah_kurir);
            if($data->persentase_rekomendasi > 50){
                $data->rekomendasi = "REKOMENDASI TINGGI";
            }else {
                $data->rekomendasi = "REKOMENDASI RENDAH";
            }
            $data->save();
        }

        return redirect()->back()->with('success','Berhasil Mengubah Variable Fuzzy');

    }


}
