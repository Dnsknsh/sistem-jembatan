<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DropPoints extends Model
{
    public function Activity()
    {
        return $this->belongsTo('App\DonationsActivity', 'id', 'drop_id');
    }
    public function Courier()
    {
        return $this->belongsTo('App\Couriers', 'id', 'drop_id');
    }
    public function Donatur()
    {
        return $this->belongsTo('App\DonationsActivity', 'id', 'drop_id');
    }
    // public function Courier()
    // {
    //     return $this->hasMany('App\Courier','id','drop_id');
    // }
}
