<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
    public function index()
    {
        $donatur = User::where('role_id',0)->get();
        return view('pages.dashboard.admin.donatur.index',compact('donatur'));
    }

    public function show($id)
    {
        $donatur = User::find($id);
        return view('pages.dashboard.admin.donatur.show',compact('donatur'));
    }


    public function edit($id)
    {
        $donatur = User::find($id);
        return view('pages.dashboard.admin.donatur.edit',compact('donatur'));
    }


    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
            'foto.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'

        ]);

        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }
        if($request->hasfile('foto')){
            $image_foto=  $request->file('foto');
            $name_foto=generateRandomString().'.'.$image_foto->getClientOriginalExtension();
            $image_foto->move(public_path().'/upload/donatur/'.$request->email,$name_foto);
            $data_foto = $name_foto;
        }

        $donatur = User::find($id);
        $donatur->name = $request->name;
        $donatur->gender= $request->gender;
        $donatur->handphone = $request->handphone;
        $donatur->email = $request->email;
        $donatur->address = $request->address;
        if($request->hasfile('foto'))
        {
            $donatur->foto=$data_foto;
        }
        $donatur->save();

        return redirect()->back()->with('success','Berhasil mengubah Data');
    }


    public function destroy($id)
    {
        $donatur = User::find($id);
        $donatur->delete();
        return redirect()->back()->with('success','Berhasil Menghapus Donatur');
    }
}
