<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function index()
    {
        $admin = User::where('role_id',1)->get();
        return view('pages.dashboard.manager.admin.index', compact('admin'));
    }

    public function create()
    {
        return view('pages.dashboard.manager.admin.add');
    }


    public function store(Request $request)
    {
        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }


        $admin = new User;
        $admin->name = $request->name;
        if($request->hasfile('foto')){
            $image_foto=  $request->file('foto');
            $name_foto=generateRandomString().'.'.$image_foto->getClientOriginalExtension();
            $image_foto->move(public_path().'/upload'.'/admin'.'/'.$admin->name.'/',$name_foto);
            $data_foto = $name_foto;
        }

        if($request->hasfile('foto'))
        {
            $admin->foto=$data_foto;
        }
        $admin->gender= $request->gender;
        $admin->role_id = 1;
        $admin->email = $request->email;
        $admin->handphone = $request->handphone;
        $admin->password = Hash::make($request->password);
        $admin->address = $request->address;
        $admin->save();
    }

    public function show($id)
    {
        $admin = User::find($id);
        return view('pages.dashboard.manager.admin.show',compact('admin'));
    }


    public function edit($id)
    {
        $admin = User::find($id);
        return view('pages.dashboard.manager.admin.edit',compact('admin'));
    }


    public function update(Request $request, $id)
    {
        $admin = User::find($id);
        $admin->name = $request->name;
        $admin->gender = $request->gender;
        $admin->handphone = $request->handphone;
        $admin->email = $request->email;
        $admin->address = $request->address;
        $admin->foto = 1;
        $admin->save();

        return redirect()->back()->with('success', 'Berhasil Mengubah admin');
    }


    public function destroy($id)
    {
        $admin = User::find($id);
        $admin->delete();

        return redirect()->back()->with('success', 'Berhasil Menghapus Admin');
    }
}
