<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePakarSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pakar_settings', function (Blueprint $table) {
            $table->Increments('id');
            $table->string('donaturBanyak')->nullable();
            $table->string('donaturSedikit')->nullable();
            $table->string('kurirBanyak')->nullable();
            $table->string('kurirSedikit')->nullable();
            $table->string('R1')->nullable();
            $table->string('R2')->nullable();
            $table->string('R3')->nullable();
            $table->string('R4')->nullable();
            $table->timestamps();
        });

        DB::table('pakar_settings')->insert(
            array(
                'donaturBanyak' => '{"batasBawah":"50","batasAtas":"200"}',
                'donaturSedikit' => '{"batasBawah":"0","batasAtas":"150"}',
                'kurirBanyak' => '{"batasBawah":"5","batasAtas":"25"}',
                'kurirSedikit' => '{"batasBawah":"0","batasAtas":"20"}',
                'R1' => '1,1,1',
                'R2' => '1,0,1',
                'R3' => '0,1,0',
                'R4' => '0,0,0',
            )
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pakar_settings');
    }
}
