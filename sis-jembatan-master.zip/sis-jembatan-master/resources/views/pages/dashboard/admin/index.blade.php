@extends('layouts.dashboard.master')
@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Admin Operator</h1>
        </div>

        <div class="row">
                <div class="col-12">
                        <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                  <h6 class="m-0 font-weight-bold text-primary">Aktivitas Jemput Bantuan</h6>
                                </div>
                                <div class="card-body">
                                  <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                      <thead>
                                        <tr>
                                          <th>Title</th>
                                          <th>Lokasi Penjemputan</th>
                                          <th>Jenis Donasi</th>
                                          <th>Jumlah</th>
                                          <th>Status</th>
                                          <th>Action</th>
                                        </tr>
                                      </thead>
                                      <tfoot>
                                              <th>title</th>
                                              <th>Lokasi Penjemputan</th>
                                              <th>Jenis Donasi</th>
                                              <th>Jumlah</th>
                                              <th>Status</th>
                                              <th>Action</th>
                                      </tfoot>
                                      <tbody>

                                              @foreach ($donationActivity as $donationActivity)
                                              <tr>
                                              <td>{{$donationActivity->Donation['title']}}</td>
                                              <td>

                                                      @if ($donationActivity->category == "money")
                                                          Transfer
                                                      @elseif($donationActivity->category == "logistic")
                                                      <iframe width="100%" height="200" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?q={{$donationActivity->langtitude}},{{$donationActivity->longtitude}}&amp;key=AIzaSyCNoV504QEhGxE0svdnhqHnYmNrOXakTQo"></iframe>
                                                      @endif

                                              </td>
                                                  <td>
                                                      @if ($donationActivity->category== "money")
                                                      Uang
                                                      @elseif($donationActivity->category == "logistic")
                                                      Logistik
                                                      @endif
                                                  </td>
                                                      <td>
                                                          @if ($donationActivity->category == "money")
                                                          Rp.{{$donationActivity->count_money}}
                                                          @elseif($donationActivity->category == "logistic")

                                                          @if ($donationActivity->count_logistic)
                                                          {{$donationActivity->count_logistic}}({{$donationActivity->satuan_logistic}})
                                                          @else
                                                          Belum dihitung
                                                          @endif
                                                          @endif
                                                      </td>
                                                      <td>
                                                          @if ($donationActivity->status == 0)
                                                              <span class="badge badge-secondary">Sedang Mencari Kurir Terdekat</span>
                                                          @elseif($donationActivity->status == 1)
                                                              <span class="badge badge-primary">Kurir Ditemukan</span>
                                                          @elseif($donationActivity->status == 2)
                                                          <span class="badge badge-success">Sudah Dijemput</span>
                                                          @elseif($donationActivity->status == 3)
                                                          <span class="badge badge-success">Sudah di Gudang Logistik Pusat</span>
                                                          @elseif($donationActivity->status == 4)
                                                          <span class="badge badge-success">Terbayar</span>
                                                          @endif
                                                      </td>
                                                      <td>
                                                            @if ($donationActivity->category == "money")
                                                                -
                                                          @elseif($donationActivity->category == "logistic")
                                                          <div class="d-flex">
                                                          <a onclick="event.preventDefault();editForm({{$donationActivity->id}});" value="{{$donationActivity->id}}" href="#" class="btn btn-primary btn-icon-split mr-2" data-toggle="modal" data-target="#editDonationActivityModal">
                                                                          <span class="icon text-white-50">
                                                                                    <i class="fas fa-edit"></i>
                                                                                  </span>
                                                                  </a>
                                                          </div>
                                                            @endif
                                                      </td>
                                                  </tr>
                                              @endforeach

                                      </tbody>
                                    </table>
                                  </div>
                                </div>
                              </div>
                </div>
        </div>
      </div>
      <!-- /.container-fluid -->


      <!-- Edit Donation Activity Modal-->
<div class="modal fade" id="editDonationActivityModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="titleModal"></h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
        <form action="#" id="formEditActivity" method="POST">
                @csrf
                @method('PUT')
                    <div class="modal-body">

                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="0">Sedang Mencari Kurir</option>
                                <option value="1">Kurir Ditemukan</option>
                                <option value="2">Sudah Dijemput Kurir</option>
                                <option value="3">Sudah di Gudang Logistik</option>
                            </select>
                        </div>
                        <div class="form-group">
                                <label for="pilihKurir">Kurir</label>
                            <select name="kurir_id" id="pilihKurir" class="form-control">
                                <option value="" selected disabled>belum Milih Kurir</option>
                                    @foreach ($kurir as $kurir)
                                    <option value="{{$kurir->id}}">{{$kurir->name}} - <strong>{{$kurir->nik}}</strong></option>
                                        @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                                <label for="pilihKurir">Posko Penyimpanan</label>
                            <select name="drop_id" id="pilihPosko" class="form-control">
                                <option value="" selected disabled>Belum Milih Posko</option>
                                    @foreach ($posko as $posko)
                                    <option value="{{$posko->id}}">{{$posko->name}}</option>
                                        @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                      <button class="btn btn-primary" type="submit">Submit</button>
                    </div>

            </form>
          </div>
        </div>
      </div>

@endsection
@section('custom-js')
    <script>
        function editForm(id) {
    $.ajax({
        type: 'GET',
        url: '/data/activity/' + id,
        success: function(data) {
            $('#formEditActivity').attr('action','/give-donation/'+data.activity.id);
            $("#titleModal").text(data.donation.title);
            $("select[name=status]").val(data.activity.status);
            $("select[name=kurir_id]").val(data.activity.kurir_id);
            $("select[name=drop_id]").val(data.activity.drop_id);
            $('#editDonationActivityModal').modal('show');
        },
        error: function(data) {
            console.log(data);
        }
    });
}

    function matchStart(params, data) {
  // If there are no search terms, return all of the data
  if ($.trim(params.term) === '') {
    return data;
  }

  // Skip if there is no 'children' property
  if (typeof data.children === 'undefined') {
    return null;
  }

  // `data.children` contains the actual options that we are matching against
  var filteredChildren = [];
  $.each(data.children, function (idx, child) {
    if (child.text.toUpperCase().indexOf(params.term.toUpperCase()) == 0) {
      filteredChildren.push(child);
    }
  });

  // If we matched any of the timezone group's children, then set the matched children on the group
  // and return the group object
  if (filteredChildren.length) {
    var modifiedData = $.extend({}, data, true);
    modifiedData.children = filteredChildren;

    // You can return modified objects from here
    // This includes matching the `children` how you want in nested data sets
    return modifiedData;
  }

  // Return `null` if the term should not be displayed
  return null;
}

$(".js-example-matcher-start").select2({
  matcher: matchStart
});
    </script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
@endsection
