<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Auth;
use App\DonationsActivity;
use App\Couriers;
use App\DropPoints;
use App\User;
use App\Fuzzy;
use App\Donations;
use App\PakarSettings;

class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index()
    {
        if (Auth::user()->role_id == 0) {
            return redirect()->to('/dashboard');
        }
        else if (Auth::user()->role_id == 1) {
            return redirect()->to('/admin');
        }
        else if (Auth::user()->role_id == 2) {
            return redirect()->to('/manager');
        }
        else if (Auth::user()->role_id == 3) {
            return redirect()->to('/pakar');
        }
    }
    //DONATUR
    public function dashboardDonatur(){
        $ownDonation = DonationsActivity::where('donatur_id',Auth::user()->id);
        return view('pages.dashboard.donatur.index',compact('ownDonation'));
    }

    public function settingsDonatur(){
        $donatur = User::find(Auth::user()->id);
        return view('pages.dashboard.donatur.settings',compact('donatur'));
    }

    public function updateDonatur(Request $request){
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
            'foto.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'

        ]);

        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }
        if($request->hasfile('foto')){
            $image_foto=  $request->file('foto');
            $name_foto=generateRandomString().'.'.$image_foto->getClientOriginalExtension();
            $image_foto->move(public_path().'/upload/donatur/'.$request->email,$name_foto);
            $data_foto = $name_foto;
        }

        $donatur = User::find(Auth::user()->id);
        $donatur->name = $request->name;
        $donatur->gender = $request->gender;
        $donatur->handphone = $request->handphone;
        $donatur->email = $request->email;
        $donatur->address = $request->address;
        if ($request->password) {
            $donatur->password = Hash::make($request->password);
        }
        if($request->hasfile('foto'))
        {
            $donatur->foto=$data_foto;
        }
        $donatur->save();

        return redirect()->back()->with('success','Berhasil mengubah Data');
    }

    //ADMIN AREA
    public function dashboardAdmin(){
        $donationActivity = DonationsActivity::where('status' , '!=' , 3)->where('category','logistic')->get();
        $kurir = Couriers::all();
        $posko = DropPoints::all();
        $donatur = User::where('role_id',0)->get();
        $donation = Donations::where('status',1)->get();
        return view('pages.dashboard.admin.index',compact('donationActivity','kurir','posko','donatur','donation'));
    }

    public function settingsAdmin(){
        $admin = User::find(Auth::user()->id);
        return view('pages.dashboard.admin.settings',compact('admin'));
    }

    public function updateAdmin(Request $request){
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
            'foto.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'

        ]);

        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }
        if($request->hasfile('foto')){
            $image_foto=  $request->file('foto');
            $name_foto=generateRandomString().'.'.$image_foto->getClientOriginalExtension();
            $image_foto->move(public_path().'/upload/admin/'.$request->email,$name_foto);
            $data_foto = $name_foto;
        }

        $admin = User::find(Auth::user()->id);
        $admin->name = $request->name;
        $admin->gender = $request->gender;
        $admin->handphone = $request->handphone;
        $admin->email = $request->email;
        $admin->address = $request->address;
        if ($request->password) {
            $admin->password = Hash::make($request->password);
        }
        if($request->hasfile('foto'))
        {
            $admin->foto=$data_foto;
        }
        $admin->save();

        return redirect()->back()->with('success','Berhasil mengubah Data');
    }


    //Pakar Area
    public function dashboardPakar(){
        $fuzzy = Fuzzy::all();
        return redirect()->to('/pakar/fuzzy/variable');
        // return view('pages.dashboard.pakar.index',compact('fuzzy'));
        // $variableFuzzy = DropPoints::select('kecamatan')
        // ->selectRaw('count(kecamatan) as posko')
        // ->selectRaw('sum(jumlah_kurir) as kurir')
        // ->selectRaw('sum(jumlah_donatur) as donatur')
        // ->groupBy('kecamatan')
        // ->orderBy('posko', 'DESC')
        // ->get();

        // $pakarSettings = PakarSettings::first();
        // $i =0;
        // foreach($variableFuzzy as $variableFuzzy){

        //     if($variableFuzzy->donatur){
        //         $xDonatur =$variableFuzzy->donatur;
        //     }else{
        //         $xDonatur=0;
        //     }

        //     if($variableFuzzy->kurir){
        //         $xKurir =$variableFuzzy->kurir;
        //     }else{
        //         $xKurir=0;
        //     }

        //     //Keanggotaan Donatur
        //     $phiDonKit[$i] = (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - $xDonatur) / (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah));

        //     $phiDonNyak[$i] = ($xDonatur - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah)) / (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah));

        //     //Keanggotaan Kurir
        //     $phiKurKit[$i] = (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - $xKurir) / (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah));

        //     $phiKurNyak[$i] = ($xKurir - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah)) / (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah));

        //     $fuzzyIkryDev[$i]['kecamatan'] = $variableFuzzy->kecamatan;
        //     $fuzzyIkryDev[$i]['phiDonKit'] = $phiDonKit[$i];
        //     $fuzzyIkryDev[$i]['phiDonNyak'] = $phiDonNyak[$i];
        //     $fuzzyIkryDev[$i]['phiKurKit'] = $phiKurKit[$i];
        //     $fuzzyIkryDev[$i]['phiKurNyak'] = $phiKurNyak[$i];

        //     $i++;
        // }

        // $i=0;
        // foreach($fuzzyIkryDev as $fuzzy){

        //     //IF DONATUR BANYAK DAN KURIR BANYAK MAKA REKOMENDASI TINGGI
        //     $r1[$fuzzy['kecamatan']] = min($fuzzy['phiDonNyak'] , $fuzzy['phiKurNyak']);
        //     //IF DONATUR BANYAK DAN KURIR SEDIKIT MAKA REKOMENDASI TINGGI
        //     $r2[$fuzzy['kecamatan']] =min($fuzzy['phiDonNyak'],$fuzzy['phiKurKit']);
        //     //IF DONATUR SEDIKIT DAN KURIR BANYAK MAKA REKOMENDASI RENDAH
        //     $r3[$fuzzy['kecamatan']] =min($fuzzy['phiDonKit'],$fuzzy['phiKurNyak']);
        //     //IF DONATUR SEDIKIT DAN KURIR SEDIKIT MAKA REKOMENDASI RENDAH
        //     $r4[$fuzzy['kecamatan']] =min($fuzzy['phiDonKit'],$fuzzy['phiKurKit']);


        //     //Cari nilai z1 lihat himpunan TINGGI:
        //     $z1[$fuzzy['kecamatan']] = ($r1[$fuzzy['kecamatan']]*100) + 0;
        //     //Cari nilai z2  lihat himpunan TINGGI:
        //     $z2[$fuzzy['kecamatan']] = ($r2[$fuzzy['kecamatan']]*100) + 0;
        //     //Cari nilai z3 lihat himpunan RENDAH
        //     $z3[$fuzzy['kecamatan']] = 100 - ($r3[$fuzzy['kecamatan']]*100);
        //     //Cari nilai z4 lihat himpunan RENDAH:
        //     $z4[$fuzzy['kecamatan']] = 100 - ($r4[$fuzzy['kecamatan']]*100);

        //     $defuzzifikasi[$i]['kecamatan']=$fuzzy['kecamatan'];

        //     $a1z1Deefuzzifikasi = $r1[$fuzzy['kecamatan']] * $z1[$fuzzy['kecamatan']];
        //     $a2z2Deefuzzifikasi = $r2[$fuzzy['kecamatan']] * $z2[$fuzzy['kecamatan']];
        //     $a3z3Deefuzzifikasi = $r3[$fuzzy['kecamatan']] * $z3[$fuzzy['kecamatan']];
        //     $a4z4Deefuzzifikasi = $r4[$fuzzy['kecamatan']] * $z4[$fuzzy['kecamatan']];

        //     $defuzzifikasi[$i]['hasil'] = ( $a1z1Deefuzzifikasi +  $a2z2Deefuzzifikasi +  $a3z3Deefuzzifikasi +  $a4z4Deefuzzifikasi) / ( $r1[$fuzzy['kecamatan']] + $r2[$fuzzy['kecamatan']] + $r3[$fuzzy['kecamatan']] + $r4[$fuzzy['kecamatan']]);

        //     $i++;
        // }
        // return view('pages.dashboard.pakar.index',compact('defuzzifikasi'));
    }

    public function settingsPakar(){
        $pakar = User::find(Auth::user()->id);
        return view('pages.dashboard.pakar.settings',compact('pakar'));
    }

    public function updatePakar(Request $request){
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
            'foto.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'

        ]);

        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }
        if($request->hasfile('foto')){
            $image_foto=  $request->file('foto');
            $name_foto=generateRandomString().'.'.$image_foto->getClientOriginalExtension();
            $image_foto->move(public_path().'/upload/pakar/'.$request->email,$name_foto);
            $data_foto = $name_foto;
        }

        $pakar = User::find(Auth::user()->id);
        $pakar->name = $request->name;
        $pakar->gender = $request->gender;
        $pakar->handphone = $request->handphone;
        $pakar->email = $request->email;
        $pakar->address = $request->address;
        if ($request->password) {
            $pakar->password = Hash::make($request->password);
        }
        if($request->hasfile('foto'))
        {
            $pakar->foto=$data_foto;
        }
        $pakar->save();

        return redirect()->back()->with('success','Berhasil mengubah Data');
    }

    // Manager Area
    const manager = 2;
    function getAllMonths(){
		$month_array = array();
		$posts_dates = DonationsActivity::orderBy( 'created_at', 'ASC' )->pluck( 'created_at' );
		$posts_dates = json_decode( $posts_dates );
		if ( ! empty( $posts_dates ) ) {
			foreach ( $posts_dates as $unformatted_date ) {
				$date = new \DateTime( $unformatted_date );
				$month_no = $date->format( 'm' );
				$month_name = $date->format( 'M' );
				$month_array[ $month_no ] = $month_name;
			}
		}
		return $month_array;
	}
	function getMonthlyPostCount( $month ) {
		$monthly_post_count = DonationsActivity::whereMonth( 'created_at', $month )->get()->count();
		return $monthly_post_count;
	}
	function dashboardManager() {
        $fuzzy = Fuzzy::all();
        $kurir = Couriers::all();
			$posko = DropPoints::all();
			$DonationsActivity = DonationsActivity::all();
            $donatur = User::where('role_id',0)->get();
            $donation = Donations::where('status',1)->get();

		$monthly_post_count_array = array();
		$month_array = $this->getAllMonths();
		$month_name_array = array();
		if ( ! empty( $month_array ) ) {
			foreach ( $month_array as $month_no => $month_name ){
				$monthly_post_count = $this->getMonthlyPostCount( $month_no );
				array_push( $monthly_post_count_array, $monthly_post_count );
				array_push( $month_name_array, $month_name );
			}
		}
		// $max_no = max( $monthly_post_count_array );
		// $max = round(( $max_no + 10/2 ) / 10 ) * 10;
		$monthly_post_data_array = array(
			'months' => $month_name_array,
			'post_count_data' => $monthly_post_count_array,
			// 'max' => $max,
        );
        // dd($monthly_post_data_array);
        return view('pages.dashboard.manager.index',compact('monthly_post_data_array','kurir','posko','donatur','donation','DonationsActivity','fuzzy'));
        // return $monthly_post_data_array;
    }

    public function settingsManager(){
        $manager = User::find(Auth::user()->id);
        return view('pages.dashboard.manager.settings',compact('manager'));
    }

    public function updateManager(Request $request){
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
            'foto.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'

        ]);

        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }

        return $randomString;
        }
        if($request->hasfile('foto')){
            $image_foto=  $request->file('foto');
            $name_foto=generateRandomString().'.'.$image_foto->getClientOriginalExtension();
            $image_foto->move(public_path().'/upload/manager/'.$request->email,$name_foto);
            $data_foto = $name_foto;
        }

        $manager = User::find(Auth::user()->id);
        $manager->name = $request->name;
        $manager->gender = $request->gender;
        $manager->handphone = $request->handphone;
        $manager->email = $request->email;
        $manager->address = $request->address;
        if ($request->password) {
            $manager->password = Hash::make($request->password);
        }
        if($request->hasfile('foto'))
        {
            $manager->foto=$data_foto;
        }
        $manager->save();

        return redirect()->back()->with('success','Berhasil mengubah Data');
    }

}
