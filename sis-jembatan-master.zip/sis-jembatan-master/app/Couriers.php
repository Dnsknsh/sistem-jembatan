<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Couriers extends Model
{
    public function DropPoint()
    {
        return $this->hasOne('App\DropPoints', 'id', 'drop_id');
    }
}
