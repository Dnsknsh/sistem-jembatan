<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DonationsActivity extends Model
{

    public function Donation()
    {
        return $this->hasOne('App\Donations', 'id', 'don_id');
    }

    public function DropPoint(){
        return $this->hasOne('App\DropPoints','id','drop_id');
    }

    public function User(){
        return $this->hasOne('App\User','id','donatur_id');
    }

    public function Courier(){
        return $this->hasOne('App\Couriers','id','kurir_id');
    }
}
