@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Tambah Kurir</h1>
            </div>

            <div class="row">
              <div class="col-md-12">

                <!-- Bagian Kartu Ketika Di perbarui -->

                <div class="card shadow mb-4">
                  <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold">Biodata Kurir</h6>
                  </div>
                  <div class="card-body">
                  <form action="{{route('kurir.store')}}" method="POST" enctype="multipart/form-data">
                    @csrf
                      <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="role" class="small font-weight-bold">NIK / No. KTP</label>
                                <input name="nik" type="text" placeholder="NIK/No. KTP" class="form-control small">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="role" class="small font-weight-bold">Handphone</label>
                                <input name="handphone" type="number" placeholder="Handphone" class="form-control small">
                            </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold">Nama</label>
                            <input name="name" type="text" class="form-control small" placeholder="Masukkan Nama Anda...">
                          </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="drop_point" class="small font-weight-bold">Drop Point</label>
                                    <select name="drop_id" id="drop_point" class="form-control">
                                        @foreach ($dropPoint as $dropPoint)
                                        <option value="{{$dropPoint->id}}">{{$dropPoint->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                              </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold" for="address">Alamat</label>
                            <textarea name="address" id="address"  rows="6" class="small form-control"></textarea>
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="small font-weight-bold">Foto</label>
                            <br>
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <span class="btn btn-outline-secondary btn-file">
                                      <span class="fileinput-new">Select file</span>
                                      <span class="fileinput-exists">Change</span>
                                      <input type="file" name="foto" multiple>
                                    </span>
                                    <span class="fileinput-filename"></span>
                                    <a href="#" class="close fileinput-exists" data-dismiss="fileinput" style="float: none">&times;</a>
                                  </div>
                          </div>
                          <div class="form-group">
                                <label class="small font-weight-bold">KTP</label>
                                <br>
                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                        <span class="btn btn-outline-secondary btn-file">
                                          <span class="fileinput-new">Select file</span>
                                          <span class="fileinput-exists">Change</span>
                                          <input type="file" name="ktp" multiple>
                                        </span>
                                        <span class="fileinput-filename"></span>
                                        <a href="#" class="close fileinput-exists" data-dismiss="fileinput" style="float: none">&times;</a>
                                      </div>
                              </div>
                        </div>
                      </div>
                      <button class="btn btn-primary" type="submit">Tambahkan</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
        </div>
@endsection
