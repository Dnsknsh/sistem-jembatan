@extends('layouts.dashboard.master')
@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Daftar Donation</h1>
        <p class="mb-4">Berikut merupakan daftar list Donation .</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Donation</h6>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Lokasi</th>
                    <th>Waktu Mulai Mulai</th>
                    <th>Waktu Berakhir</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tfoot>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Lokasi</th>
                    <th>Waktu Mulai Mulai</th>
                    <th>Waktu Berakhir</th>
                    <th>Status</th>
                    <th>Action</th>
                </tfoot>
                <tbody>
                    @foreach ($donation as $donation)
                    <tr>
                    <td>{{$donation->id}}</td>
                    <td>{{$donation->title}}</td>
                    <td>{{$donation->location}}</td>
                    <td>{{$donation->startDate}}</td>
                    <td>{{$donation->endDate}}</td>
                    <td>

                        @if ($donation->status == 0)
                            <span class="badge badge-secondary">Belum di setujui</span>
                        @elseif($donation->status == 1)
                            <span class="badge badge-success">Aktif</span>
                        @elseif($donation->status == 2)
                        <span class="badge badge-danger">Tidak Di Setujui</span>
                        @endif

                    </td>
                    <td class="d-flex">
                        <button onclick="location.href='{{route('donation.show',$donation->id)}}'" class="btn btn-primary btn-icon-split mr-2">
                                <span class="icon text-white-50">
                                          <i class="fas fa-eye"></i>
                                        </span>
                        </button>
                          <button onclick="location.href='{{route('donation.edit',$donation->id)}}'" class="btn btn-success btn-icon-split mr-2">
                            <span class="icon text-white-50">
                              <i class="fas fa-edit"></i>
                            </span>
                        </button>
                        <form action="{{route('donation.destroy',$donation->id)}}" method="post">
                            @csrf
                            {{method_field('DELETE')}}
                            <button type="submit" class="btn btn-danger btn-icon-split">
                                    <span class="icon text-white-50">
                                      <i class="fas fa-trash"></i>
                                    </span>
                            </button>
                        </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->
@endsection
