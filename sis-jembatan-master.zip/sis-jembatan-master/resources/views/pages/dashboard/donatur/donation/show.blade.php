@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">{{$ownDonation->Donation->title}}</h1>
            </div>

            <div class="row">
                <div class="col-md-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-2">
                        Kurir
                    </div>
                    <div class="card-body">
                            <img src="{{asset('/upload/'.$ownDonation->Courier->drop_id.'/kurir/'.$ownDonation->Courier->nik.'/foto/'. $ownDonation->Courier->foto)}}" class="img-fluid"  alt="">
                    </div>
                </div>
                <div class="card shadow mb-4">
                        <div class="card-header py-2">
                            Kontak Kurir
                        </div>
                        <div class="card-body">
                                <table class="table table-striped">
                                    <tbody>
                                        <tr>
                                            <td class="font-weight-bold">Nama</td>
                                            <td>{{$ownDonation->Courier->name}}</td>
                                        </tr>
                                        <tr>
                                                <td class="font-weight-bold">Handphone</td>
                                                <td>{{$ownDonation->Courier->handphone}}</td>
                                        </tr>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>
              <div class="col-md-8">

                <!-- Bagian Kartu Ketika Di perbarui -->

                <div class="card shadow mb-4">
                  <div class="card-header py-2">
                    <h6 class="m-0 ">Detail</h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <td>Nama Kampanye</td>
                            <td>{{$ownDonation->Donation->title}}</td>
                            </tr>
                                <tr>
                                        <td>
                                            Status
                                        </td>
                                        <td>
                                                @if ($ownDonation->status == 0)
                                              <span class="badge badge-secondary">Sedang Mencari Kurir Terdekat</span>
                                          @elseif($ownDonation->status == 1)
                                              <span class="badge badge-primary">Kurir Ditemukan</span>
                                          @elseif($ownDonation->status == 2)
                                          <span class="badge badge-success">Sudah Dijemput</span>
                                          @elseif($ownDonation->status == 3)
                                          <span class="badge badge-success">Sudah di Gudang Logistik Pusat</span>
                                          @elseif($ownDonation->status == 4)
                                          <span class="badge badge-success">Terbayar</span>
                                          @endif
                                        </td>
                                    </tr>
                                    @if ($ownDonation->category == "money")
                                    <tr>
                                            <td>Jenis Donasi</td>
                                            <td>Uang</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Nominal
                                            </td>
                                            <td>
                                               Rp. {{$ownDonation->count_money}}
                                            </td>
                                        </tr>
                                        @elseif($ownDonation->category == "logistic")
                                        <tr>
                                            <td>Jenis Donasi</td>
                                            <td>Logistik</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Keterangan
                                            </td>
                                            <td>
                                                {{$ownDonation->description_logistic}}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Nominal
                                            </td>
                                            <td>
                                                {{$ownDonation->count_logistic}} ( {{$ownDonation->satuan_logistic}} )
                                            </td>
                                        </tr>
                                          @endif
                        </table>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
@endsection
