@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Settings Fuzzy Variable</h1>
        </div>
        <div class="row">
          <!-- Area Chart -->
          <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Variable & Himpunan</h6>
              </div>
              <!-- Card Body -->
              <div class="card-body">
              <form class="form" action="{{route('updateFuzzyVariable')}}" method="POST" >
                @csrf
                {{method_field('PUT')}}
                <div class="row">

                        <div class="col-12">
                            <h4>Donatur</h4>
                        </div>
                        <div class="form-group row col-12 col-md-6">
                            <div class="col-6">
                                    <label>Donatur Banyak Batas Bawah</label>
                                <input type="number" class="form-control" value="{{json_decode($pakarSettings->donaturBanyak)->batasBawah}}" placeholder="Batas Bawah" name="donaturBanyak_batasBawah">
                            </div>
                            <div class="col-6">
                                    <label>Donatur Banyak Batas Atas</label>
                                    <input type="number" class="form-control" value="{{json_decode($pakarSettings->donaturBanyak)->batasAtas}}" placeholder="Batas Atas" name="donaturBanyak_batasAtas">
                                </div>

                        </div>
                        <div class="form-group row col-12 col-md-6">


                            <div class="col-6">
                                    <label>Donatur Sedikit Batas Bawah</label>
                                <input type="number" class="form-control" value="{{json_decode($pakarSettings->donaturSedikit)->batasBawah}}" placeholder="Batas Bawah" name="donaturSedikit_batasBawah">
                            </div>
                            <div class="col-6">
                                    <label>Donatur Sedikit Batas Atas</label>
                                    <input type="number" class="form-control" value="{{json_decode($pakarSettings->donaturSedikit)->batasAtas}}" placeholder="Batas Atas" name="donaturSedikit_batasAtas">
                                </div>

                        </div>

                    </div>
                    <div class="row">
                            <div class="col-12">
                                <h4>Kurir</h4>
                            </div>
                            <div class="form-group row col-12 col-md-6">

                                <div class="col-6">
                                        <label>Kurir Banyak Batas Bawah</label>
                                        <input type="number" class="form-control" value="{{json_decode($pakarSettings->kurirBanyak)->batasBawah}}" placeholder="Batas Bawah" name="kurirBanyak_batasBawah">
                                    </div>
                                <div class="col-6">
                                        <label>Kurir Banyak Batas Atas</label>
                                        <input type="number" class="form-control" value="{{json_decode($pakarSettings->kurirBanyak)->batasAtas}}" placeholder="Batas Atas" name="kurirBanyak_batasAtas">
                                    </div>

                            </div>
                            <div class="form-group row col-12 col-md-6">
                                <div class="col-6">
                                        <label>Kurir Sedikit Batas Bawah</label>
                                    <input type="number" class="form-control" value="{{json_decode($pakarSettings->kurirSedikit)->batasBawah}}" placeholder="Batas Bawah" name="kurirSedikit_batasBawah">
                                </div>
                                <div class="col-6">
                                        <label>Kurir Sedikit Batas Atas</label>
                                        <input type="number" class="form-control" value="{{json_decode($pakarSettings->kurirSedikit)->batasAtas}}" placeholder="Batas Atas" name="kurirSedikit_batasAtas">
                                    </div>

                            </div>

                        </div>
                <div class="form-group col-12 text-center mt-5">
                        <button class="btn btn-primary" type="submit">Ubah Data</button>
                    </div>
              </form>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->
@endsection
