@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">
         <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Tambah Kampanye Donasi</h1>
       </div>


        <div class="row">

          <!-- Area Chart -->
          <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Form Tambah Kampanye Donasi</h6>
              </div>
              <!-- Card Body -->
              <div class="card-body">
              <form class="form" action="{{route('donation.store')}}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                 <div class="form-group col-12 col-md-6">
                    <label for="namaLogistik">Nama Kampanye</label>
                    <input type="text" class="form-control" id="namaLogistik" placeholder="Nama Logistik" name="title">
                 </div>
                 <div class="form-group col-12 col-md-6">
                        <label for="namaLogistik">Lokasi</label>
                        <input type="text" class="form-control" id="namaLogistik" placeholder="Lokasi" name="location">
                </div>
                 <div class="form-group col-12 col-md-6">
                    <label for="tanggal">Tanggal Mulai</label>
                    <input type="date" class="form-control" value="{{date('Y-m-d H:i:s')}}" id="tanggal" placeholder="Tanggal" name="startDate">
                </div>
                <div class="form-group col-12 col-md-6">
                        <label for="tanggal">Tanggal Selesai</label>
                        <input type="date" class="form-control" value="{{date('Y-m-d H:i:s')}}" id="tanggal" placeholder="Tanggal" name="endDate" >
                    </div>
                <div class="form-group col-12 col-md-6">
                    <label for="namaLogistik">Thumbnail</label>
                    <div class="fileinput fileinput-new d-block" data-provides="fileinput">
  <div class="fileinput-new img-thumbnail" style="display:none;width: 200px; height: 150px;">
    <img data-src=""  alt="...">
  </div>
  <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px;"></div>
  <div>
    <span class="btn btn-outline-secondary btn-file"><span class="fileinput-new">Upload Foto</span><span class="fileinput-exists">Ubah</span><input type="file" name="thumbnail" required></span>
    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Hapus</a>
  </div>
</div>
                 </div>
                 <div class="form-group col-12 col-md-6">
                        <div class="custom-control custom-checkbox my-1 mr-sm-2">
                                <input type="checkbox" class="custom-control-input" id="acc_money" name="acc_money">
                                <label class="custom-control-label" for="acc_money">Accept Money</label>
                              </div>

                              <div class="custom-control custom-checkbox my-1 mr-sm-2">
                                    <input type="checkbox" class="custom-control-input" id="acc_logistic" name="acc_logistic">
                                    <label class="custom-control-label" for="acc_logistic">Accept Logistik</label>
                                  </div>
                </div>
                <div class="form-group col-12 col-md-12">
                        <label for="stok">Description</label>
                        <textarea name="description" id="" cols="30" rows="5" class="form-control"></textarea>
                    </div>
                <div class="form-group col-12 text-center">
                    <button class="btn btn-primary" type="submit">Tambah Kampanye Donasi</button>
                </div>
                </div>
              </form>
              </div>
            </div>
          </div>

          <!-- Pie Chart -->
          <div class="col-xl-4 col-lg-5">

            <!-- Approach -->
            <div class="card shadow mb-4">
              <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">PENGUMUMAN</h6>
              </div>
              <div class="card-body">
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus consequatur nisi, alias adipisci nulla sequi, laboriosam quisquam consectetur, incidunt nihil fuga ducimus? Maiores cupiditate, quae laborum molestiae culpa magnam dolores.</p>
              </div>
            </div>

          </div>
        </div>

      </div>
      <!-- /.container-fluid -->
@endsection
