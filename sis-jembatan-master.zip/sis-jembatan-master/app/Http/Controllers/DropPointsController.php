<?php

namespace App\Http\Controllers;

use App\DropPoints;
use App\DonationsActivity;
use Illuminate\Http\Request;

class DropPointsController extends Controller
{

    public function index()
    {
        $dropPoint = DropPoints::all();
        return view('pages.dashboard.admin.drop-point.index',compact('dropPoint'));
    }


    public function create()
    {
        return view('pages.dashboard.admin.drop-point.add');
    }


    public function store(Request $request)
    {
        $this->validate($request,[
            'name' => 'required',
            'handphone' => 'required',
            'langtitude' => 'required',
            'longtitude' => 'required',
            'address' => 'required'
        ]);

        $dropPoint = new DropPoints;
        $dropPoint->name = $request->name;
        $dropPoint->handphone = $request->handphone;
        $dropPoint->langtitude = $request->langtitude;
        $dropPoint->longtitude = $request->longtitude;
        $dropPoint->kecamatan = $request->kecamatan;
        $dropPoint->kode_pos = $request->kode_pos;
        $dropPoint->address = $request->address;
        $dropPoint->save();


        return redirect()->to('admin/drop-point')->with('success','Berhasil menambah Drop Point');
    }


    public function show($id)
    {
        $dropPoint = DropPoints::find($id);
        $activity = DonationsActivity::where('drop_id',$id)->get();
        return view('pages.dashboard.admin.drop-point.show',compact('dropPoint','activity'));
    }


    public function edit($id)
    {
        $dropPoint = DropPoints::find($id);
        return view('pages.dashboard.admin.drop-point.edit',compact('dropPoint'));
    }


    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'name' => 'required',
            'handphone' => 'required',
            'langtitude' => 'required',
            'longtitude' => 'required',
            'address' => 'required'
        ]);

        $dropPoint = DropPoints::find($id);
        $dropPoint->name = $request->name;
        $dropPoint->handphone = $request->handphone;
        $dropPoint->langtitude = $request->langtitude;
        $dropPoint->longtitude = $request->longtitude;
        $dropPoint->kecamatan = $request->kecamatan;
        $dropPoint->kode_pos = $request->kode_pos;
        $dropPoint->address = $request->address;
        $dropPoint->save();


        return redirect()->back()->with('success','Berhasil mengubah Drop Point');
    }


    public function destroy($id)
    {
        $dropPoint = DropPoints::find($id);
        $dropPoint->delete();
        return redirect()->back()->with('success','Berhasil Menghapus Drop Point');
    }
}
