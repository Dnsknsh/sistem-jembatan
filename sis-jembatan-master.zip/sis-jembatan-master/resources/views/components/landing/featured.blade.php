<section class="section section-shaped" id="featured">
    <div class="shape shape-style-1 shape-default">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
    <div class="container py-md">
      <div class="row justify-content-between align-items-center p-3">


            <div id="carousel_example" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      <li data-target="#carousel_example" data-slide-to="0" class="active"></li>
                      <li data-target="#carousel_example" data-slide-to="1"></li>
                    </ol>
                    <div class="carousel-inner">
                        @php($i=1)
                        @foreach ($latest as $featured)
                        @if($featured->status == 1)
                        <div class="carousel-item {{$i == 1 ? 'active' : ''}}">
                            <div class="row">

                                    <div class="col-lg-6 p-5 mb-lg-auto order-lg-2">
                                            <div class="rounded shadow-lg overflow-hidden">
                                                    <img class="img-fluid" src="{{asset('/upload/donation/'.$featured->title.'_'.$featured->startDate.'/'.$featured->thumbnail)}}" alt="">
                                            </div>
                                        </div>
                                    <div class="col-lg-6 mb-5 mb-lg-0 order-lg-1">
                                            <h1 class="text-white font-weight-light">{{$featured->title}}</h1>
                                            <span class="badge badge-pill badge-secondary">{{$featured->location}}</span>
                                            @if ($featured->acc_logistic == "on")
                                            <span class="badge badge-pill badge-secondary"><i class="fa fa-truck"></i></span>
                                            @endif
                                            @if($featured->acc_money == "on")
                                            <span class="badge badge-pill badge-secondary"><i class="fa fa-money"></i></span>
                                            @endif
                                            <p class="lead text-white mt-4">
                                                {{ str_limit($featured->description,100) }}
                                            </p>
                                            <div class="progress-wrapper">
                                                    <div class="progress">
                                                      <div class="progress-bar bg-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
                                                    </div>
                                                  </div>
                                                  <div class="row">
                                                      <div class="col-6 text-white">
                                                            <small>
                                                                    Mulai<br>{{date('d-m-Y', strtotime($featured->startDate))}}
                                                            </small>
                                                      </div>
                                                      <div class="col-6 text-white text-right">
                                                            <small>
                                                                    Selesai<br>{{date('d-m-Y', strtotime($featured->endDate))}}
                                                                 </small>
                                                      </div>
                                                  </div>
                                                <a href="{{route('campaign',$featured->id)}}" class="btn btn-white mt-4">Donasi Sekarang</a>
                                    </div>
                            </div>
                      </div>

                      @php($i++)
                        @endif
                        @endforeach
                    </div>
                  </div>

        {{-- <div class="col-lg-5 mb-5 mb-lg-0">
          <h1 class="text-white font-weight-light">Bootstrap carousel</h1>
          <p class="lead text-white mt-4">Argon Design System comes with four pre-built pages to help you get started faster. You can change the text and images and you're good to go.</p>
          <a href="https://demos.creative-tim.com/argon-design-system/docs/components/alerts.html" class="btn btn-white mt-4">See all components</a>
        </div>
        <div class="col-lg-6 mb-lg-auto">
          <div class="rounded shadow-lg overflow-hidden transform-perspective-right">
            <div id="carousel_example" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                <li data-target="#carousel_example" data-slide-to="0" class="active"></li>
                <li data-target="#carousel_example" data-slide-to="1"></li>
              </ol>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img class="img-fluid" src="/landing/img/theme/img-1-1200x1000.jpg" alt="First slide">
                </div>
                <div class="carousel-item">
                  <img class="img-fluid" src="/landing/img/theme/img-2-1200x1000.jpg" alt="Second slide">
                </div>
              </div>
              <a class="carousel-control-prev" href="#carousel_example" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carousel_example" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
            </div>
          </div>
        </div> --}}
      </div>
    </div>
  </section>
