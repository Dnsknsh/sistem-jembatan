@extends('layouts.dashboard.master')
@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Pakar</h1>
        </div>
        <!-- Content Row -->
        <div class="row">


<!-- Content Column -->
<div class="col-lg-12 mb-4">

                <!-- Project Card Example -->
                <div class="card shadow mb-4">
                        <div class="card-header py-3">
                          <h6 class="m-0 font-weight-bold text-primary">persentase Posko</h6>
                        </div>
                        <div class="card-body">
                          @foreach ($fuzzy as $fuzzy)

                          @if ($fuzzy->persentase_rekomendasi <= 0)
                          <h4 class="small font-weight-bold">{{$fuzzy->kecamatan}}<span class="float-right">0%</span></h4>
                          <div class="progress mb-4">
                                  <div class="progress-bar bg-danger" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          @elseif ($fuzzy->persentase_rekomendasi <= 40)
                          <h4 class="small font-weight-bold">{{$fuzzy->kecamatan}}<span class="float-right">{{$fuzzy->persentase_rekomendasi}}%</span></h4>
                          <div class="progress mb-4">
                                  <div class="progress-bar bg-danger" role="progressbar" style="width: {{$fuzzy->persentase_rekomendasi}}%" aria-valuenow="{{$fuzzy->persentase_rekomendasi}}" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          @elseif($fuzzy->persentase_rekomendasi <= 75)
                          <h4 class="small font-weight-bold">{{$fuzzy->kecamatan}}<span class="float-right">{{$fuzzy->persentase_rekomendasi}}%</span></h4>
                          <div class="progress mb-4">
                                  <div class="progress-bar bg-primary" role="progressbar" style="width: {{$fuzzy->persentase_rekomendasi}}%" aria-valuenow="{{$fuzzy->persentase_rekomendasi}}" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          @elseif($fuzzy->persentase_rekomendasi <= 100)
                          <h4 class="small font-weight-bold">{{$fuzzy->kecamatan}}<span class="float-right">{{$fuzzy->persentase_rekomendasi}}%</span></h4>
                          <div class="progress mb-4">
                                  <div class="progress-bar bg-success" role="progressbar" style="width: {{$fuzzy->persentase_rekomendasi}}%" aria-valuenow="{{$fuzzy->persentase_rekomendasi}}" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          @endif
                          @endforeach
                        </div>
                      </div>

  </div>
        </div>


      </div>
      <!-- /.container-fluid -->


@endsection
