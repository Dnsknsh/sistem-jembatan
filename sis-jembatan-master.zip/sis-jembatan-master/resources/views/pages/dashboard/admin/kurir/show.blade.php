@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Biodata Kurir</h1>
            </div>

            <div class="row">
                <div class="col-md-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-2">
                        Foto
                    </div>
                    <div class="card-body">
                            <img src="{{asset('/upload/'.$kurir->drop_id.'/kurir/'.$kurir->nik.'/foto/'.$kurir->foto)}}" class="img-fluid"  alt="">
                    </div>
                </div>
                <div class="card shadow mt-4 mb-4">
                        <div class="card-header py-2">
                            KTP
                        </div>
                        <div class="card-body">
                            <img src="{{asset('/upload/'.$kurir->drop_id.'/kurir/'.$kurir->nik.'/ktp/'.$kurir->ktp)}}" class="img-fluid" alt="">
                        </div>
                    </div>
                </div>
              <div class="col-md-8">

                <!-- Bagian Kartu Ketika Di perbarui -->

                <div class="card shadow mb-4">
                  <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold">Biodata</h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <td>NIK</td>
                                <td>{{$kurir->nik}}</td>
                            </tr>
                            <tr>
                                <td>Nama</td>
                                <td>{{$kurir->name}}</td>
                            </tr>
                            <tr>
                                <td>Handphone</td>
                                <td>{{$kurir->handphone}}</td>
                            </tr>
                            <tr>
                                <td>Drop Point</td>
                                <td>{{$kurir->DropPoint['name']}}</td>
                            </tr>
                            <tr>
                                <td>Alamat</td>
                                <td>{{$kurir->address}}</td>
                            </tr>
                            <tr>
                                <td></td>
                            </tr>
                        </table>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
@endsection
