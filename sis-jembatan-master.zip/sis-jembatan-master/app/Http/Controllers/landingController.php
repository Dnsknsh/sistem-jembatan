<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Donations;
use App\DonationsActivity;
use App\User;

class landingController extends Controller
{
    public function index(){
        $latest = Donations::latest()->take(2)->get();
        $donation = Donations::where('status',1)->get();
        $donatur_count = User::where('role_id',0)->count();
        $allCount = DonationsActivity::sum('count_money');
        return view('pages.landing.index',compact('donation','donatur_count','latest','allCount'));
    }

    public function showDonation($id){
        $donation = Donations::find($id);
        $activity = DonationsActivity::where('don_id',$id)->get();
        return view('pages.landing.showDonation',compact('donation','activity'));
    }

}
