<?php

namespace App\Http\Controllers;

use Auth;
use App\DonationsActivity;
use App\DropPoints;
use App\Fuzzy;
use App\PakarSettings;
use Illuminate\Http\Request;

class DonationsActivityController extends Controller
{

    public function index()
    {

    }


    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        if ($request->category == 'money') {
            $this->validate($request,[
                'don_id' => 'required|int',
                'category' => 'required',
                'count_money' => 'required|int'
            ]);
        } elseif($request->category == 'logistic') {
            $this->validate($request,[
                'don_id' => 'required|int',
                'category' => 'required',
                'description_logistic' => 'required',
                'langtitude' => 'required',
                'longtitude' => 'required',
            ]);

        }

        $giveDonation = new DonationsActivity;
        $giveDonation->don_id = $request->don_id;
        $giveDonation->donatur_id = Auth::user()->id;
        if ($request->category == 'money') {
            $giveDonation->status = 4; // Terbayar
            $giveDonation->count_money = $request->count_money;
            $giveDonation->metode = 1; //Metode di Transfer
        }else if($request->category == 'logistic'){
            $giveDonation->status = 0; //Mencari kurir
            $giveDonation->kecamatan = $request->kecamatan;
            $giveDonation->kode_pos = $request->kode_pos;
            $giveDonation->count_logistic = $request->count_logistic;
            $giveDonation->satuan_logistic = $request->satuan_logistic;
            $giveDonation->langtitude = $request->langtitude;
            $giveDonation->longtitude = $request->longtitude;
            $giveDonation->description_logistic = $request->description_logistic;
            $giveDonation->metode = 0; //Metode Di jemput


        }
        $giveDonation->category = $request->category;
        $giveDonation->save();

        if ($request->category == 'money') {
            return redirect('/dashboard/my-donation')->with('success','Terima Kasih Telah Ikut Berdonasi');
        }else if($request->category == 'logistic'){
            return redirect('/dashboard/my-donation')->with('success','Terima Kasih Telah Ikut Berdonasi');
        }
    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }


    public function update(Request $request, $id)
    {
        function fuzzyTsukamoto($xDonatur, $xKurir){
            $pakarSettings = PakarSettings::first();
            if($xDonatur <= number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah)){

                $phiDonaturBanyak = 0;
                $phiDonaturSedikit = 0;

            }else if($xDonatur >= number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah) || $xDonatur <= number_format(json_decode($pakarSettings->donaturBanyak)->batasAtas)){

            //Keanggotaan Donatur Banyak
            $phiDonaturBanyak = ($xDonatur - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah)) / (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah));

            //Keanggotaan Donatur Sedikit
            $phiDonaturSedikit = (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - $xDonatur) / (number_format(json_decode($pakarSettings->donaturSedikit)->batasAtas) - number_format(json_decode($pakarSettings->donaturBanyak)->batasBawah));

            }else if($xDonatur >= number_format(json_decode($pakarSettings->donaturBanyak)->batasAtas)){
                $phiDonaturBanyak = 1;
                $phiDonaturSedikit = 1;
            }

            if($xKurir <= number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah)){

                $phiKurirBanyak = 0;
                $phiKurirSedikit = 0;

            }else if($xKurir >= number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah) || $xKurir <= number_format(json_decode($pakarSettings->kurirBanyak)->batasAtas)){

            //Keanggotaan Kurir Sedikit
            $phiKurirSedikit = (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - $xKurir) / (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah));
            //Keanggotaan Kurir Banyak
            $phiKurirBanyak = ($xKurir - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah)) / (number_format(json_decode($pakarSettings->kurirSedikit)->batasAtas) - number_format(json_decode($pakarSettings->kurirBanyak)->batasBawah));

            }else if($xKurir >= number_format(json_decode($pakarSettings->kurirBanyak)->batasAtas)){
                $phiKurirBanyak = 1;
                $phiKurirSedikit = 1;
            }

    //IF DONATUR BANYAK DAN KURIR BANYAK MAKA REKOMENDASI TINGGI
    $r1 = min($phiDonaturBanyak , $phiKurirBanyak);
    //IF DONATUR BANYAK DAN KURIR SEDIKIT MAKA REKOMENDASI TINGGI
    $r2 =min($phiDonaturBanyak , $phiKurirSedikit);
    //IF DONATUR SEDIKIT DAN KURIR BANYAK MAKA REKOMENDASI RENDAH
    $r3 =min($phiDonaturSedikit , $phiKurirBanyak);
    //IF DONATUR SEDIKIT DAN KURIR SEDIKIT MAKA REKOMENDASI RENDAH
    $r4 =min($phiDonaturSedikit , $phiKurirSedikit);


    //Cari nilai z1 lihat himpunan TINGGI:
    $z1 = ($r1*100) + 0;
    //Cari nilai z2  lihat himpunan TINGGI:
    $z2 = ($r2*100) + 0;
    //Cari nilai z3 lihat himpunan RENDAH
    $z3= 100 - ($r3*100);
    //Cari nilai z4 lihat himpunan RENDAH:
    $z4 = 100 - ($r4*100);

    if(( ($r1*$z1) +  ($r2*$z2) +  ($r3*$z4) +  ($r4*$z4)) == 0 || ( $r1 + $r2 + $r3 + $r4)){
        return 0;
    }else {
        $defuzzifikasi = ( ($r1*$z1) +  ($r2*$z2) +  ($r3*$z4) +  ($r4*$z4)) / ( $r1 + $r2 + $r3 + $r4);
        return $defuzzifikasi;
    }
        }

        $this->validate($request,[
            'status' => 'required|int',
            'kurir_id' => 'required|int',
            'drop_id' => 'required|int'
        ]);

        $activity = DonationsActivity::find($id);
        $activity->status = $request->status;
        $activity->kurir_id = $request->kurir_id;
        $activity->drop_id = $request->drop_id;
        $activity->save();

        $posko =DropPoints::find($request->drop_id);
        $posko->jumlah_donatur = $posko->jumlah_donatur + 1;
        $posko->save();

        $cekKecamatan = Fuzzy::where('kecamatan',$posko->kecamatan)->first();
        if($cekKecamatan){
            $fuzzy = $cekKecamatan;
            $fuzzy->jumlah_donatur +=1;
            $fuzzy->persentase_rekomendasi = fuzzyTsukamoto($fuzzy->jumlah_donatur , $fuzzy->jumlah_kurir);
            if( $fuzzy->persentase_rekomendasi > 50){
                $fuzzy->rekomendasi = "REKOMENDASI TINGGI";
            }else {
                $fuzzy->rekomendasi = "REKOMENDASI RENDAH";
            }
            $fuzzy->save();
        }else{
            $fuzzy = new Fuzzy;
            $fuzzy->kecamatan=$posko->kecamatan;
            $fuzzy->jumlah_donatur = 1 ;
            $fuzzy->jumlah_kurir = 0;
            $fuzzy->persentase_rekomendasi = fuzzyTsukamoto($fuzzy->jumlah_donatur , $fuzzy->jumlah_kurir);
            if( $fuzzy->persentase_rekomendasi > 50){
                $fuzzy->rekomendasi = "REKOMENDASI TINGGI";
            }else {
                $fuzzy->rekomendasi = "REKOMENDASI RENDAH";
            }
            $fuzzy->save();
        }

        return redirect()->back()->with('success','Berhasil Mengubah');
    }


    public function destroy($id)
    {
        //
    }

    public function showOwn(){
        $ownDonation = DonationsActivity::where('donatur_id',Auth::user()->id)->get();
        return view('pages.dashboard.donatur.donation.index',compact('ownDonation'));
    }

    public function detailOwn($id){
        $ownDonation = DonationsActivity::find($id);
        return view('pages.dashboard.donatur.donation.show',compact('ownDonation'));
    }
}
