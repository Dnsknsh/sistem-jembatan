@extends('layouts.dashboard.master')
@section('content')
     <!-- Begin Page Content -->
     <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Manager</h1>
        </div>

        <!-- Content Row -->
        <div class="row">

          <!-- Card Donatur -->
          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Jumlah Donatur</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{$donatur->count()}}</div>
                  </div>
                  <div class="col-auto">
                  <i class="fas fa-people-carry fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Donasi -->
          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Jumlah Kampanye Donasi</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{$donation->count()}}</div>
                  </div>
                  <div class="col-auto">
                  <i class="fas fa-hand-holding-usd fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Kurir -->
          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Kurir yang tersedia</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{$kurir->count()}}</div>
                  </div>
                  <div class="col-auto">
                  <i class="fas fa-user-friends fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Posko -->
          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Posko Donasi</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{$posko->count()}}</div>
                  </div>
                  <div class="col-auto">
                  <i class="fas fa-map-marker-alt fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Content Row -->

        <div class="row">

<!-- Area Chart -->
          <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Statistika Donasi</h6>
                <div class="dropdown no-arrow">
                  <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                  </a>
                </div>
              </div>
              <!-- Card Body -->
              <div class="card-body">
                <div class="chart-area">
                  <canvas id="myAreaChart"></canvas>
                </div>
              </div>
            </div>
          </div>

          <!-- Pie Chart -->
          <div class="col-xl-6 col-lg-6">
            <!-- Project Card Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Rekomendasi Pembukaan Posko</h6>
                </div>
                <div class="card-body">
                  @foreach ($fuzzy as $fuzzy)

                  @if ($fuzzy->persentase_rekomendasi <= 0)
                <h4 class="small font-weight-bold">{{$fuzzy->kecamatan}}<span class="float-right">{{$fuzzy->Rekomendasi}} [0%]</span></h4>
                  <div class="progress mb-4">
                          <div class="progress-bar bg-danger" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  @elseif ($fuzzy->persentase_rekomendasi <= 40)
                  <h4 class="small font-weight-bold">{{$fuzzy->kecamatan}}<span class="float-right">{{$fuzzy->Rekomendasi}} [{{$fuzzy->persentase_rekomendasi}}%]</span></h4>
                  <div class="progress mb-4">
                          <div class="progress-bar bg-danger" role="progressbar" style="width: {{$fuzzy->persentase_rekomendasi}}%" aria-valuenow="{{$fuzzy->persentase_rekomendasi}}" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  @elseif($fuzzy->persentase_rekomendasi <= 75)
                  <h4 class="small font-weight-bold">{{$fuzzy->kecamatan}}<span class="float-right">{{$fuzzy->Rekomendasi}} [{{$fuzzy->persentase_rekomendasi}}%]</span></h4>
                  <div class="progress mb-4">
                          <div class="progress-bar bg-primary" role="progressbar" style="width: {{$fuzzy->persentase_rekomendasi}}%" aria-valuenow="{{$fuzzy->persentase_rekomendasi}}" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  @elseif($fuzzy->persentase_rekomendasi <= 100)
                  <h4 class="small font-weight-bold">{{$fuzzy->kecamatan}}<span class="float-right">{{$fuzzy->Rekomendasi}} [{{$fuzzy->persentase_rekomendasi}}%]</span></h4>
                  <div class="progress mb-4">
                          <div class="progress-bar bg-success" role="progressbar" style="width: {{$fuzzy->persentase_rekomendasi}}%" aria-valuenow="{{$fuzzy->persentase_rekomendasi}}" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  @endif
                  @endforeach
                </div>
              </div>
          </div>
        </div>

        <!-- Content Row -->
        <div class="row">



          <!-- maps -->
          <div class="col-xl-6 col-lg-7">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Persebaran Lokasi Posko</h6>
              </div>
              <!-- Card Body -->
              <div class="card-body">
              <div id="googleMap" class="z-depth-1-half " style="height: 500px;border-radius: 10px; box-shadow: 0px 0px 20px #c7cad1;"></div>
              </div>
            </div>
          </div>

          <div class="col-xl-6 col-lg-7">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Persebaran Lokasi Donatur</h6>
              </div>
              <!-- Card Body -->
              <div class="card-body">
              <div id="googleMap2" class="z-depth-1-half " style="height: 500px;border-radius: 10px; box-shadow: 0px 0px 20px #c7cad1;"></div>
              </div>
            </div>
          </div>

        </div>

      </div>
      <!-- /.container-fluid -->

@endsection
@section('custom-js')
<script>
var data = @json($monthly_post_data_array);
var ctx = document.getElementById("myAreaChart");
var myLineChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: data.months  ,
    datasets: [{
      lineTension: 0.3,
      backgroundColor: "rgba(78, 115, 223, 0.05)",
      borderColor: "rgba(78, 115, 223, 1)",
      pointRadius: 3,
      pointBackgroundColor: "rgba(78, 115, 223, 1)",
      pointBorderColor: "rgba(78, 115, 223, 1)",
      pointHoverRadius: 3,
      pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
      pointHoverBorderColor: "rgba(78, 115, 223, 1)",
      pointHitRadius: 10,
      pointBorderWidth: 2,
      data: data.post_count_data,

    }],
  },
  options: {
    maintainAspectRatio: false,
    layout: {
      padding: {
        left: 10,
        right: 25,
        top: 25,
        bottom: 0
      }
    },
    scales: {
      xAxes: [{
        time: {
          unit: 'date'
        },
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          maxTicksLimit: 7
        }
      }],
      yAxes: [{
        ticks: {
          maxTicksLimit: 5,
          padding: 10,
          callback: function(value, index, values) {
            return number_format(value);
          }
        },
        gridLines: {
          color: "rgb(234, 236, 244)",
          zeroLineColor: "rgb(234, 236, 244)",
          drawBorder: false,
          borderDash: [2],
          zeroLineBorderDash: [2]
        }
      }],
    },
    legend: {
      display: false
    },
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      titleMarginBottom: 10,
      titleFontColor: '#6e707e',
      titleFontSize: 14,
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      intersect: false,
      mode: 'index',
      caretPadding: 10,
      callbacks: {
        label: function(tooltipItem, chart) {
          var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
          return datasetLabel + "Banyak Donasi  "+ number_format(tooltipItem.yLabel);
        }
      }
    }
  }
});
</script>
<script>
      var infowindow = new google.maps.InfoWindow();
      var maker;
      var dropPoints = @json($posko);
      console.log(dropPoints);
      var map = new google.maps.Map(document.getElementById('googleMap'), {
          zoom: 11,
          center: new google.maps.LatLng(-7.697588402404246, 110.401229),
          mapTypeControl: false,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
      });
      for (var i = 0; i < dropPoints.length; i++) {
            marker = new google.maps.Marker({
              position: new google.maps.LatLng(dropPoints[i].langtitude, dropPoints[i].longtitude),
              map: map,
              animation: google.maps.Animation.DROP
            });
            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                  return function() {

                    infowindow.setContent("<center>"+"<h4>"+"Posko "+dropPoints[i].name +"</h4>"+"<h6>"+"Jumlah Kurir : " + dropPoints[i].jumlah_kurir+"</h6>"+"</center>"+ dropPoints[i].address);
                    infowindow.open(map, marker);
                  }
                })(marker, i));
        }
</script>

<script>
      var infowindow = new google.maps.InfoWindow();
      // var maker;
      var donaturLocation = @json($DonationsActivity);
      console.log(donaturLocation);
      var map = new google.maps.Map(document.getElementById('googleMap2'), {
          zoom: 12,
          center: new google.maps.LatLng(-7.7157052101117225, 110.46835473887052),
          mapTypeControl: false,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
      });
      for (var i = 0; i < donaturLocation.length; i++) {
            marker = new google.maps.Marker({
              position: new google.maps.LatLng(donaturLocation[i].langtitude, donaturLocation[i].longtitude),
              map: map,
              animation: google.maps.Animation.DROP
            });
            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                  return function() {
console.log(donaturLocation[i].category);
                      if(donaturLocation[i].category == 'logistic'){
                        infowindow.setContent(
                        "<h6>"+"Donasi  : " + donaturLocation[i].description_logistic+ " ("+ donaturLocation[i].count_logistic+donaturLocation[i].satuan_logistic+") </h6>"+
                        // "<h6>"+"Satuan Donasi : " + donaturLocation[i].satuan_logistic+"</h6>"+
                      "Kecamatan : "+donaturLocation[i].kecamatan);
                      }




                    infowindow.open(map, marker);
                  }
                })(marker, i));
        }
</script>
@endsection
